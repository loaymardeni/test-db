import 'package:firebase_auth/firebase_auth.dart';
import 'firestore_service.dart';
import 'dart:developer'; // ✅

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirestoreService _firestoreService = FirestoreService();

  bool isGuest = false;

  Future<User?> signInWithEmail(String email, String password) async {
    try {
      final result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      isGuest = false;
      return result.user;
    } catch (e) {
      log("🔥 خطأ في تسجيل الدخول: $e");
      return null;
    }
  }

  Future<User?> registerWithEmail(String email, String password) async {
    try {
      final result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = result.user;
      if (user != null) {
        await _firestoreService.createUser(
          userId: user.uid,
          email: user.email ?? '',
          role: 'user',
        );
        isGuest = false;
      }

      return user;
    } catch (e) {
      log("🔥 خطأ في إنشاء الحساب: $e");
      return null;
    }
  }

  void signInAsGuest() {
    isGuest = true;
    log("🟡 المستخدم يتابع كزائر");
  }

  Future<void> signOut() async {
    await _auth.signOut();
    isGuest = false;
  }

  User? get currentUser => _auth.currentUser;

  Stream<User?> get userChanges => _auth.userChanges();
}
