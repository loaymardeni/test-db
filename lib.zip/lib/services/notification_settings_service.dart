import 'package:shared_preferences/shared_preferences.dart';

class NotificationSettingsService {
  static const _keys = {
    'login': 'notif_login',
    'passwordChange': 'notif_password_change',
    'failedLogin': 'notif_failed_login',
    'message': 'notif_message',
    'booking': 'notif_booking',
    'review': 'notif_review',
    'policy': 'notif_policy',
    'email': 'notif_email',
    'push': 'notif_push',
    'all': 'notif_all',
  };

  static Future<void> setNotification(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keys[key]!, value);
  }

  static Future<bool> getNotification(
    String key, {
    bool defaultValue = true,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keys[key]!) ?? defaultValue;
  }

  // تحميل كل الإعدادات دفعة واحدة
  static Future<Map<String, bool>> loadAllSettings() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'login': prefs.getBool(_keys['login']!) ?? true,
      'passwordChange': prefs.getBool(_keys['passwordChange']!) ?? true,
      'failedLogin': prefs.getBool(_keys['failedLogin']!) ?? false,
      'message': prefs.getBool(_keys['message']!) ?? true,
      'booking': prefs.getBool(_keys['booking']!) ?? true,
      'review': prefs.getBool(_keys['review']!) ?? true,
      'policy': prefs.getBool(_keys['policy']!) ?? false,
      'email': prefs.getBool(_keys['email']!) ?? true,
      'push': prefs.getBool(_keys['push']!) ?? true,
      'all': prefs.getBool(_keys['all']!) ?? true,
    };
  }
}
