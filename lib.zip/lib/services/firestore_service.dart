import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:developer'; // ✅ استدعاء log بديل print

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // ✅ إنشاء مستخدم جديد بقاعدة البيانات
  Future<void> createUser({
    required String userId,
    required String email,
    required String role,
  }) async {
    try {
      await _firestore.collection('users').doc(userId).set({
        'email': email,
        'role': role,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      log("🔥 فشل في إنشاء المستخدم في Firestore: $e");
    }
  }

  // ✅ الحصول على بيانات مستخدم
  Future<DocumentSnapshot<Map<String, dynamic>>?> getUser(String userId) async {
    try {
      final doc = await _firestore.collection('users').doc(userId).get();
      return doc;
    } catch (e) {
      log("🔥 خطأ أثناء جلب بيانات المستخدم: $e");
      return null;
    }
  }

  // ✅ تحديث بيانات المستخدم
  Future<void> updateUser(String userId, Map<String, dynamic> data) async {
    try {
      await _firestore.collection('users').doc(userId).update(data);
    } catch (e) {
      log("🔥 فشل في تحديث بيانات المستخدم: $e");
    }
  }
}
