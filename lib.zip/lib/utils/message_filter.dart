class MessageFilter {
  static final List<RegExp> _blockedPatterns = [
    RegExp(r'[0-9]{6,}'), // أرقام طويلة (مثل أرقام هواتف أو حسابات)
    RegExp(
      r'\b(?:gmail|hotmail|yahoo|outlook)\.com\b',
      caseSensitive: false,
    ), // إيميلات
    RegExp(r'@[a-zA-Z0-9_]+'), // أسماء مستخدمين مثل @username
    RegExp(r'https?:\/\/[^\s]+'), // روابط
  ];

  static bool containsSensitiveInfo(String message) {
    for (final pattern in _blockedPatterns) {
      if (pattern.hasMatch(message)) return true;
    }
    return false;
  }
}
