import 'package:flutter/material.dart';
import 'package:harbooq/router/app_router.dart'; // تأكد أن هذا الملف يحتوي: final GoRouter appRouter = GoRouter(...);

void main() {
  runApp(const HarbooqApp());
}

class HarbooqApp extends StatelessWidget {
  const HarbooqApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      routerConfig: appRouter, // هذا لازم يكون معرف بـ app_router.dart
    );
  }
}
