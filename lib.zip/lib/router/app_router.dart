import 'package:go_router/go_router.dart';
import 'package:harbooq/models/property.dart';

// 🟢 الشاشات الرئيسية
import 'package:harbooq/screens/splash/splash_screen.dart';
import 'package:harbooq/screens/onboarding/onboarding_screen.dart';
import 'package:harbooq/screens/main/main_tabs_screen.dart';

// 🔵 الحساب الشخصي والإعدادات
import 'package:harbooq/screens/profile/profile_view_screen.dart';
import 'package:harbooq/screens/profile/account_settings/account_settings_screen.dart';
import 'package:harbooq/screens/profile/account_settings/personal_info_screen.dart';
import 'package:harbooq/screens/profile/account_settings/identity_verification_screen.dart';
import 'package:harbooq/screens/profile/account_settings/login_security_screen.dart';
import 'package:harbooq/screens/profile/account_settings/notifications_screen.dart';
import 'package:harbooq/screens/profile/account_settings/payments_screen.dart';
import 'package:harbooq/screens/profile/account_settings/accessibility_screen.dart';
import 'package:harbooq/screens/profile/account_settings/privacy_screen.dart';

// 🟠 الدعم والمساعدة
import 'package:harbooq/screens/support/support_home_screen.dart';
import 'package:harbooq/screens/support/report_problem_screen.dart';
import 'package:harbooq/screens/support/faq_center_screen.dart';
import 'package:harbooq/screens/support/faq_details_screen.dart';
import 'package:harbooq/screens/support/smart_support_screen.dart'
    as support_ai;

// 🔴 القوانين والسياسات
import 'package:harbooq/screens/profile/legal/legal_screen.dart';
import 'package:harbooq/screens/profile/legal/terms_screen.dart';
import 'package:harbooq/screens/profile/legal/privacy_policy_screen.dart';
import 'package:harbooq/screens/profile/legal/company_info_screen.dart';
import 'package:harbooq/screens/profile/legal/report_content_screen.dart';

// 🔐 تسجيل الدخول
import 'package:harbooq/screens/auth/login_screen.dart';

// 🟣 الدردشة
import 'package:harbooq/screens/chats/chats_screen.dart';
import 'package:harbooq/screens/chats/chats_list_screen.dart';
import 'package:harbooq/screens/chats/chat_detail_screen.dart';
import 'package:harbooq/screens/chats/favorite_messages_screen.dart';
import 'package:harbooq/screens/chats/smart_support_screen.dart' as chat_ai;

// ✅ التقييمات
import 'package:harbooq/screens/rate/rate_stay_screen.dart';

// 🟡 القائمة الذكية: عقار / سيارة / خدمة
import 'package:harbooq/screens/car/add/car_rent_form_screen.dart';
import 'package:harbooq/screens/service/add/service_offer_form_screen.dart';
import 'package:harbooq/screens/property/add/add_sell_property_screen.dart';
import 'package:harbooq/screens/property/add/add_sell_property_images_screen.dart';
import 'package:harbooq/screens/property/add/add_rent_property_screen.dart'
    as rent_form;
import 'package:harbooq/screens/property/add/add_rent_property_images_screen.dart'
    as rent_images;
import 'package:harbooq/screens/property/add/sell_property_preview_screen.dart';
import 'package:harbooq/screens/property/add/rent_property_preview_screen.dart';
import 'package:harbooq/screens/property/property_details_screen.dart';
import 'package:harbooq/screens/property/rent_property_details_screen.dart';

final GoRouter appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const SplashScreen(seenOnboarding: false),
    ),
    GoRoute(
      path: '/onboarding',
      builder: (context, state) => const OnboardingScreen(),
    ),
    GoRoute(path: '/main', builder: (context, state) => const MainTabsScreen()),

    // الحساب الشخصي
    GoRoute(
      path: '/profile_view',
      builder: (context, state) => const ProfileViewScreen(),
    ),
    GoRoute(
      path: '/account_settings',
      builder: (context, state) => const AccountSettingsScreen(),
    ),
    GoRoute(
      path: '/account_settings/personal_info',
      builder: (context, state) => const PersonalInfoScreen(),
    ),
    GoRoute(
      path: '/account_settings/identity_verification',
      builder: (context, state) => const IdentityVerificationScreen(),
    ),
    GoRoute(
      path: '/account_settings/login_security',
      builder: (context, state) => const LoginSecurityScreen(),
    ),
    GoRoute(
      path: '/account_settings/notifications',
      builder: (context, state) => const NotificationsScreen(),
    ),
    GoRoute(
      path: '/account_settings/payments',
      builder: (context, state) => const PaymentsScreen(),
    ),
    GoRoute(
      path: '/account_settings/accessibility',
      builder: (context, state) => const AccessibilityScreen(),
    ),
    GoRoute(
      path: '/account_settings/privacy',
      builder: (context, state) => const PrivacyScreen(),
    ),

    // الدعم والمساعدة
    GoRoute(
      path: '/support',
      builder: (context, state) => const SupportHomeScreen(),
    ),
    GoRoute(
      path: '/support/report',
      builder: (context, state) => const ReportProblemScreen(),
    ),
    GoRoute(
      path: '/support/faq',
      builder: (context, state) => const FaqCenterScreen(),
    ),
    GoRoute(
      path: '/support/faq/:id',
      builder: (context, state) {
        final id = state.pathParameters['id'];
        return FaqDetailsScreen(faqId: id ?? '');
      },
    ),
    GoRoute(
      path: '/support/ai_form',
      builder: (context, state) => const support_ai.SmartSupportScreen(),
    ),
    GoRoute(
      path: '/support/ai_chat',
      builder: (context, state) => const chat_ai.SmartSupportScreen(),
    ),

    // القوانين والسياسات
    GoRoute(path: '/legal', builder: (context, state) => const LegalScreen()),
    GoRoute(path: '/terms', builder: (context, state) => const TermsScreen()),
    GoRoute(
      path: '/privacy-policy',
      builder: (context, state) => const PrivacyPolicyScreen(),
    ),
    GoRoute(
      path: '/company-info',
      builder: (context, state) => const CompanyInfoScreen(),
    ),
    GoRoute(
      path: '/report-content',
      builder: (context, state) => const ReportContentScreen(),
    ),

    // تسجيل الدخول
    GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),

    // الدردشة
    GoRoute(path: '/chats', builder: (context, state) => const ChatsScreen()),
    GoRoute(
      path: '/chats/list',
      builder: (context, state) => const ChatsListScreen(),
    ),
    GoRoute(
      path: '/chats/detail',
      builder: (context, state) {
        final userName = state.extra as String? ?? 'مستخدم';
        return ChatDetailScreen(userName: userName);
      },
    ),
    GoRoute(
      path: '/chats/favorites',
      builder: (context, state) => const FavoriteMessagesScreen(),
    ),
    GoRoute(
      path: '/chats/support',
      builder: (context, state) => const chat_ai.SmartSupportScreen(),
    ),

    // التقييمات
    GoRoute(
      path: '/reviews/rate',
      builder: (context, state) {
        final roomTitle = state.extra as String? ?? 'الإقامة';
        return RateStayScreen(roomTitle: roomTitle);
      },
    ),

    // عقارات - إضافة
    GoRoute(
      path: '/add/sell',
      builder: (context, state) => const AddSellPropertyScreen(),
    ),
    GoRoute(
      path: '/add/sell/images',
      builder: (context, state) {
        final data = state.extra as Map<String, dynamic>? ?? {};
        return AddSellPropertyImagesScreen(data: data);
      },
    ),
    GoRoute(
      path: '/add/sell/preview',
      builder: (context, state) {
        final data = state.extra as Map<String, dynamic>? ?? {};
        return SellPropertyPreviewScreen(data: data);
      },
    ),
    GoRoute(
      path: '/add/rent',
      builder: (context, state) => const rent_form.AddRentPropertyScreen(),
    ),
    GoRoute(
      path: '/add/rent/images',
      builder: (context, state) {
        final propertyData = state.extra as Map<String, dynamic>? ?? {};
        return rent_images.AddRentPropertyImagesScreen(
          propertyData: propertyData,
        );
      },
    ),

    GoRoute(
      path: '/add/rent/preview',
      builder: (context, state) {
        final data = state.extra as Map<String, dynamic>? ?? {};
        return RentPropertyPreviewScreen(data: data);
      },
    ),
    GoRoute(
      path: '/add/service',
      builder: (context, state) => const ServiceOfferFormScreen(),
    ),
    GoRoute(
      path: '/add/car',
      builder: (context, state) => const CarRentFormScreen(),
    ),

    // تفاصيل العقارات
    GoRoute(
      path: '/property/details',
      builder: (context, state) {
        final data = state.extra as Map<String, dynamic>? ?? {};
        return SellPropertyPreviewScreen(data: data); // أو أي شاشة معاينة
      },
    ),

    GoRoute(
      path: '/rent/details',
      builder: (context, state) {
        final property = state.extra as Property;
        return RentPropertyDetailsScreen(property: property);
      },
    ),
  ],
);
