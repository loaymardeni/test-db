import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SmartAddSheet extends StatelessWidget {
  final void Function(String action) onSelect;

  const SmartAddSheet({super.key, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'ماذا تريد أن تضيف؟',
            style: GoogleFonts.cairo(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          _buildOption(
            context,
            icon: Icons.home_outlined,
            title: 'عقار للبيع',
            action: 'sell_property',
          ),
          _buildOption(
            context,
            icon: Icons.key_outlined,
            title: 'عقار للإيجار',
            action: 'rent_property',
          ),
          _buildOption(
            context,
            icon: Icons.directions_car_outlined,
            title: 'سيارة للإيجار',
            action: 'rent_car',
          ),
          _buildOption(
            context,
            icon: Icons.miscellaneous_services_outlined,
            title: 'تقديم خدمة',
            action: 'offer_service',
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('إغلاق', style: GoogleFonts.cairo(fontSize: 16)),
          ),
        ],
      ),
    );
  }

  Widget _buildOption(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String action,
  }) {
    return ListTile(
      leading: Icon(icon, color: Colors.pink),
      title: Text(title, style: GoogleFonts.cairo(fontSize: 16)),
      onTap: () => onSelect(action),
    );
  }
}
