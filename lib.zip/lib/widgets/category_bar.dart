import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:google_fonts/google_fonts.dart';

class CategoryBar extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onSelect;
  final List<Map<String, String>> categories;

  const CategoryBar({
    super.key,
    required this.selected,
    required this.onSelect,
    required this.categories,
  });

  @override
  Widget build(BuildContext context) {
    final int itemCount = categories.length;

    return SizedBox(
      height: 110, // ارتفاع موحّد
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(), // بدون Scroll
        padding: const EdgeInsets.symmetric(horizontal: 12),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: itemCount, // توزيع تلقائي حسب عدد العناصر
          mainAxisSpacing: 0,
          crossAxisSpacing: 0,
          childAspectRatio: 0.8, // للتحكم بشكل العنصر
        ),
        itemCount: itemCount,
        itemBuilder: (context, i) {
          final isSelected = selected == i;

          return GestureDetector(
            onTap: () => onSelect(i),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: isSelected
                        ? Border.all(
                            color: const Color.fromRGBO(233, 30, 99, 0.5),
                            width: 1.4,
                          )
                        : null,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  padding: const EdgeInsets.all(6),
                  child: SizedBox(
                    width: 38,
                    height: 38,
                    child: Lottie.asset(
                      categories[i]['icon']!,
                      fit: BoxFit.contain,
                      animate: isSelected,
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  categories[i]['title'] ?? '',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.cairo(
                    fontSize: 12,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
