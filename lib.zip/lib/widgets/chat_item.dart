import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class ChatItem extends StatelessWidget {
  final String userName;
  final String lastMessage;
  final String time;
  final bool isUnread;
  final String? avatarUrl;
  final bool isSupport;
  final VoidCallback? onTap;

  const ChatItem({
    super.key,
    required this.userName,
    required this.lastMessage,
    required this.time,
    this.isUnread = false,
    this.avatarUrl,
    this.isSupport = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: isSupport
          ? AppTheme.accentColor.withAlpha((0.12 * 255).round())
          : Colors.white,
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: isUnread ? 5 : 2,
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: avatarUrl == null
              ? (isSupport ? AppTheme.accentColor : AppTheme.primaryColor)
              : Colors.transparent,
          radius: 25,
          backgroundImage: avatarUrl != null ? NetworkImage(avatarUrl!) : null,
          child: avatarUrl == null
              ? Icon(
                  isSupport ? Icons.headset_mic : Icons.person,
                  color: Colors.white,
                  size: 26,
                )
              : null,
        ),
        title: Text(
          userName,
          style: GoogleFonts.cairo(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: AppTheme.primaryColor,
          ),
        ),
        subtitle: Text(
          lastMessage,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.cairo(fontSize: 14, color: AppTheme.greyColor),
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              time,
              style: GoogleFonts.cairo(fontSize: 12, color: AppTheme.greyColor),
            ),
            if (isUnread)
              Container(
                margin: const EdgeInsets.only(top: 4),
                width: 10,
                height: 10,
                decoration: const BoxDecoration(
                  color: Colors.pink,
                  shape: BoxShape.circle,
                ),
              ),
          ],
        ),
        contentPadding: const EdgeInsets.symmetric(
          vertical: 10,
          horizontal: 16,
        ),
        onTap: onTap ?? () {},
      ),
    );
  }
}
