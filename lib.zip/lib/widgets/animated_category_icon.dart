import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class AnimatedCategoryIcon extends StatefulWidget {
  final String lottiePath;
  final bool isActive;

  const AnimatedCategoryIcon({
    super.key,
    required this.lottiePath,
    required this.isActive,
  });

  @override
  State<AnimatedCategoryIcon> createState() => _AnimatedCategoryIconState();
}

class _AnimatedCategoryIconState extends State<AnimatedCategoryIcon>
    with SingleTickerProviderStateMixin {
  double scale = 1.0;

  void _triggerAnimation() {
    setState(() => scale = 1.2);
    Future.delayed(const Duration(milliseconds: 150), () {
      if (mounted) setState(() => scale = 1.0);
    });
  }

  @override
  void didUpdateWidget(covariant AnimatedCategoryIcon oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !oldWidget.isActive) {
      _triggerAnimation();
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      scale: scale,
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeOut,
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: widget.isActive
              ? Colors.pink.withAlpha((0.18 * 255).round())
              : Colors.transparent,
        ),
        padding: const EdgeInsets.all(6),
        child: Lottie.asset(
          widget.lottiePath,
          width: 64,
          height: 64,
          animate: widget.isActive,
        ),
      ),
    );
  }
}
