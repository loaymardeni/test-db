import 'package:flutter/material.dart';
import 'package:harbooq/theme/app_theme.dart';

class MainBottomNav extends StatelessWidget {
  final int current;
  final ValueChanged<int> onTabChanged;
  final VoidCallback onAddPressed;

  const MainBottomNav({
    super.key,
    required this.current,
    required this.onTabChanged,
    required this.onAddPressed,
  });

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      shape: const CircularNotchedRectangle(), // ✅ الشكل المنحني للزر العائم
      notchMargin: 8, // المسافة بين الزر والشريط
      color: Colors.white,
      elevation: 12,
      child: SizedBox(
        height: 64,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            IconButton(
              icon: Icon(
                current == 0 ? Icons.home : Icons.home_outlined,
                color: current == 0
                    ? AppTheme.primaryColor
                    : AppTheme.greyColor,
              ),
              onPressed: () => onTabChanged(0),
            ),
            IconButton(
              icon: Icon(
                current == 1 ? Icons.favorite : Icons.favorite_border,
                color: current == 1
                    ? AppTheme.primaryColor
                    : AppTheme.greyColor,
              ),
              onPressed: () => onTabChanged(1),
            ),
            const SizedBox(width: 40), // مساحة لزر الزائد
            IconButton(
              icon: Icon(
                current == 2 ? Icons.bookmark : Icons.bookmark_outline,
                color: current == 2
                    ? AppTheme.primaryColor
                    : AppTheme.greyColor,
              ),
              onPressed: () => onTabChanged(2),
            ),
            IconButton(
              icon: Icon(
                current == 3 ? Icons.person : Icons.person_outline,
                color: current == 3
                    ? AppTheme.primaryColor
                    : AppTheme.greyColor,
              ),
              onPressed: () => onTabChanged(3),
            ),
          ],
        ),
      ),
    );
  }
}
