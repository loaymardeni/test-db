import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class PropertyCard extends StatelessWidget {
  final String image;
  final String title;
  final String subtitle;
  final bool isFavorite;
  final VoidCallback onFavorite;

  const PropertyCard({
    super.key,
    required this.image,
    required this.title,
    required this.subtitle,
    required this.onFavorite,
    this.isFavorite = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 170,
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha((0.05 * 255).round()),
            blurRadius: 7,
            offset: const Offset(1, 3),
          ),
        ],
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(16),
                ),
                child: Image.asset(
                  image,
                  width: 170,
                  height: 110,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 9.0),
                child: Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.cairo(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 9.0),
                child: Text(
                  subtitle,
                  style: GoogleFonts.cairo(
                    fontSize: 13,
                    color: AppTheme.greyColor,
                  ),
                ),
              ),
              const SizedBox(height: 12),
            ],
          ),
          Positioned(
            top: 9,
            right: 9,
            child: GestureDetector(
              onTap: onFavorite,
              child: CircleAvatar(
                backgroundColor: Colors.white70,
                radius: 16,
                child: Icon(
                  isFavorite ? Icons.favorite : Icons.favorite_border,
                  size: 20,
                  color: isFavorite ? Colors.pink : AppTheme.greyColor,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
