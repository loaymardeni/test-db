import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class EmergencyButton extends StatelessWidget {
  final VoidCallback? onEmergencyPressed;

  const EmergencyButton({super.key, this.onEmergencyPressed});

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      backgroundColor: Colors.redAccent,
      foregroundColor: Colors.white,
      elevation: 6,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(100),
        side: const BorderSide(color: Colors.white, width: 3),
      ),
      tooltip: 'زر الطوارئ',
      child: const Icon(Icons.warning_amber_rounded, size: 36),
      onPressed: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '🚨 تم تفعيل زر الطوارئ. يتم الآن اتخاذ الإجراءات اللازمة.',
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            backgroundColor: Colors.redAccent,
            duration: const Duration(seconds: 2),
          ),
        );

        // نفذ الإجراءات الفعلية عند الضغط (إذا تم توفيرها)
        if (onEmergencyPressed != null) {
          onEmergencyPressed!();
        }
      },
    );
  }
}
