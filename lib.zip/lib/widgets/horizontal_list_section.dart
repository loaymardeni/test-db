import 'package:flutter/material.dart';
import 'property_card.dart';

class HorizontalListSection extends StatelessWidget {
  final String title;
  final List<Map<String, dynamic>> items;
  final Function(int) onFavorite;

  const HorizontalListSection({
    super.key,
    required this.title,
    required this.items,
    required this.onFavorite,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ),
        SizedBox(
          height: 250, // تم رفع الارتفاع لتفادي خطأ overflow
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: items.length,
            separatorBuilder: (context, index) => const SizedBox(width: 10),
            itemBuilder: (context, i) {
              final item = items[i];
              return PropertyCard(
                image: item['image'],
                title: item['title'],
                subtitle: item['subtitle'],
                isFavorite: item['isFavorite'],
                onFavorite: () => onFavorite(i),
              );
            },
          ),
        ),
      ],
    );
  }
}
