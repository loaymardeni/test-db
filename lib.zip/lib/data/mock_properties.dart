// lib/data/mock_properties.dart

import '../models/property.dart';

final List<Property> mockProperties = [];
