// lib/data/dummy_rooms.dart
// بيانات وهمية لاختبار الواجهات - لا تستخدم في الإنتاج

import '../models/room_model.dart';

const List<Room> dummyRooms = [
  Room(
    id: 'r1',
    title: 'غرفة مفروشة في دمشق',
    imageUrl: 'https://i.imgur.com/2nCt3Sbl.jpg',
    location: 'دمشق - المزة',
    pricePerNight: 25.0,
    capacity: 2,
    description:
        'غرفة مريحة ومجهزة بالكامل تقع في قلب مدينة دمشق، قريبة من جميع المرافق.',
  ),
  Room(
    id: 'r2',
    title: 'غرفة أنيقة في حلب',
    imageUrl: 'https://i.imgur.com/tGbaZCYl.jpg',
    location: 'حلب - العزيزية',
    pricePerNight: 30.0,
    capacity: 2,
    description:
        'غرفة نظيفة بتصميم حديث تقع في منطقة هادئة وآمنة ضمن حي العزيزية.',
  ),
  Room(
    id: 'r3',
    title: 'ستوديو صغير في اللاذقية',
    imageUrl: 'https://i.imgur.com/JT8XjRv.jpg',
    location: 'اللاذقية - مشروع الزراعة',
    pricePerNight: 20.0,
    capacity: 2,
    description:
        'ستوديو عملي ومناسب للأفراد مع إطلالة جميلة وموقع مميز في اللاذقية.',
  ),
];
