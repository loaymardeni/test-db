class Property {
  final String id;
  final String title;
  final String location;
  final double price;
  final String description;
  final String docsUrl;
  final List<String> imageUrls;

  Property({
    required this.id,
    required this.title,
    required this.location,
    required this.price,
    required this.description,
    required this.docsUrl,
    required this.imageUrls,
  });

  Property copyWith({
    String? id,
    String? title,
    String? location,
    double? price,
    String? description,
    String? docsUrl,
    List<String>? imageUrls,
  }) {
    return Property(
      id: id ?? this.id,
      title: title ?? this.title,
      location: location ?? this.location,
      price: price ?? this.price,
      description: description ?? this.description,
      docsUrl: docsUrl ?? this.docsUrl,
      imageUrls: imageUrls ?? this.imageUrls,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'location': location,
      'price': price,
      'description': description,
      'docsUrl': docsUrl,
      'imageUrls': imageUrls,
    };
  }

  factory Property.fromMap(Map<String, dynamic> map) {
    return Property(
      id: map['id'],
      title: map['title'],
      location: map['location'],
      price: (map['price'] as num).toDouble(),
      description: map['description'],
      docsUrl: map['docsUrl'],
      imageUrls: List<String>.from(map['imageUrls'] ?? []),
    );
  }
}
