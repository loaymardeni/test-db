// lib/models/booking.dart

/// يمثل عملية حجز لعقار معيّن.
/// status يمكن أن تكون: 'مؤكد'، 'ملغي'، 'معلق'، إلخ.
class Booking {
  final String id;
  final String propertyTitle;
  final int nights;
  final DateTime startDate;
  final String status;

  Booking({
    required this.id,
    required this.propertyTitle,
    required this.nights,
    required this.startDate,
    required this.status,
  });

  // تحويل الحجز إلى Map (اختياري للتخزين/التواصل مع API)
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'propertyTitle': propertyTitle,
      'nights': nights,
      'startDate': startDate.toIso8601String(),
      'status': status,
    };
  }

  // إنشاء الحجز من Map (اختياري)
  factory Booking.fromMap(Map<String, dynamic> map) {
    return Booking(
      id: map['id'],
      propertyTitle: map['propertyTitle'],
      nights: map['nights'],
      startDate: DateTime.parse(map['startDate']),
      status: map['status'],
    );
  }
}
