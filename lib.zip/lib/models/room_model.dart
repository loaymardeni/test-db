// lib/models/room_model.dart

import 'dart:convert';

class Room {
  final String id;
  final String title;
  final String description;
  final String location;
  final String imageUrl;
  final double pricePerNight;
  final int capacity;

  const Room({
    required this.id,
    required this.title,
    required this.description,
    required this.location,
    required this.imageUrl,
    required this.pricePerNight,
    required this.capacity,
  });

  /// Creates a Room from a Map (e.g. from route arguments or JSON)
  factory Room.fromMap(Map<String, dynamic> map) {
    return Room(
      id: map['id'] as String? ?? '',
      title: map['title'] as String? ?? '',
      description: map['description'] as String? ?? '',
      location: map['location'] as String? ?? '',
      imageUrl: map['imageUrl'] as String? ?? '',
      pricePerNight: (map['pricePerNight'] as num?)?.toDouble() ?? 0.0,
      capacity: map['capacity'] as int? ?? 1,
    );
  }

  /// Converts this Room to a Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'location': location,
      'imageUrl': imageUrl,
      'pricePerNight': pricePerNight,
      'capacity': capacity,
    };
  }

  /// Helper for JSON encode/decode
  String toJson() => jsonEncode(toMap());
  factory Room.fromJson(String source) => Room.fromMap(jsonDecode(source));
}
