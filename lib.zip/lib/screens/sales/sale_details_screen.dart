import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:harbooq/theme/app_theme.dart';

class SaleDetailsScreen extends StatefulWidget {
  final String title;
  final String location;
  final double price;
  final String imageUrl;
  final String description;
  final List<String> documentUrls;
  final String sellerName;

  const SaleDetailsScreen({
    super.key,
    required this.title,
    required this.location,
    required this.price,
    required this.imageUrl,
    required this.description,
    required this.documentUrls,
    required this.sellerName,
  });

  @override
  State<SaleDetailsScreen> createState() => _SaleDetailsScreenState();
}

class _SaleDetailsScreenState extends State<SaleDetailsScreen> {
  Future<void> _launchDocument(String url, bool open) async {
    try {
      final uri = Uri.parse(url);
      final launched = await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );
      if (!launched && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(open ? 'تعذّر فتح الوثيقة' : 'تعذّر تنزيل الوثيقة'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('حدث خطأ: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'تفاصيل العقار للبيع',
          style: GoogleFonts.cairo(
            fontWeight: FontWeight.bold,
            color: AppTheme.primaryColor,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildImageSection(),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildTitleAndLocation(),
                  const SizedBox(height: 12),
                  _buildPriceInfo(),
                  const SizedBox(height: 20),
                  _buildDescription(),
                  const SizedBox(height: 20),
                  _buildDocuments(),
                  const SizedBox(height: 28),
                  _buildContactButton(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageSection() {
    return Card(
      margin: const EdgeInsets.all(14),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      elevation: 5,
      clipBehavior: Clip.antiAlias,
      child: Image.network(
        widget.imageUrl,
        width: double.infinity,
        height: 220,
        fit: BoxFit.cover,
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Container(
            height: 220,
            color: Colors.grey.shade200,
            child: const Center(child: CircularProgressIndicator()),
          );
        },
        errorBuilder: (context, error, stackTrace) => Container(
          height: 220,
          color: Colors.grey.shade200,
          child: Center(
            child: Icon(
              Icons.broken_image,
              size: 60,
              color: Colors.grey.shade400,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTitleAndLocation() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.title,
          style: GoogleFonts.cairo(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(
          widget.location,
          style: GoogleFonts.cairo(fontSize: 18, color: AppTheme.greyColor),
        ),
      ],
    );
  }

  Widget _buildPriceInfo() {
    return Text(
      'السعر: ${widget.price.toStringAsFixed(0)} \$',
      style: GoogleFonts.cairo(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: AppTheme.primaryColor,
      ),
    );
  }

  Widget _buildDescription() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'الوصف:',
          style: GoogleFonts.cairo(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: AppTheme.primaryColor,
          ),
        ),
        const SizedBox(height: 8),
        Text(widget.description, style: GoogleFonts.cairo(fontSize: 16)),
      ],
    );
  }

  Widget _buildDocuments() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'الوثائق القانونية:',
          style: GoogleFonts.cairo(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: AppTheme.primaryColor,
          ),
        ),
        const SizedBox(height: 8),
        if (widget.documentUrls.isEmpty)
          Text(
            'لا توجد وثائق مرفقة',
            style: GoogleFonts.cairo(color: AppTheme.greyColor),
          ),
        ...widget.documentUrls.map((docUrl) {
          final fileName = Uri.decodeFull(docUrl.split('/').last);
          return Card(
            elevation: 1,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            margin: const EdgeInsets.symmetric(vertical: 6),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              child: Row(
                children: [
                  const Icon(Icons.picture_as_pdf, color: Colors.teal),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      fileName,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.cairo(fontSize: 15),
                    ),
                  ),
                  TextButton(
                    onPressed: () => _launchDocument(docUrl, true),
                    child: const Text('فتح'),
                  ),
                  TextButton(
                    onPressed: () => _launchDocument(docUrl, false),
                    child: const Text('تنزيل'),
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildContactButton() {
    return ElevatedButton.icon(
      onPressed: () {
        Navigator.pushNamed(
          context,
          '/contact_seller',
          arguments: widget.sellerName,
        );
      },
      icon: const Icon(Icons.chat, size: 22),
      label: const Text('اتصل بالبائع'),
      style: ElevatedButton.styleFrom(
        backgroundColor: AppTheme.primaryColor,
        padding: const EdgeInsets.symmetric(vertical: 16),
        textStyle: GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.bold),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }
}
