import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';
import '../../models/room_model.dart';
import 'package:go_router/go_router.dart';

class RoomManagementScreen extends StatefulWidget {
  final List<Room> userRooms;

  const RoomManagementScreen({super.key, required this.userRooms});

  @override
  State<RoomManagementScreen> createState() => _RoomManagementScreenState();
}

class _RoomManagementScreenState extends State<RoomManagementScreen> {
  late List<Room> rooms;

  @override
  void initState() {
    super.initState();
    rooms = List.from(widget.userRooms);
  }

  void _confirmDeleteRoom(Room room) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          'حذف الغرفة',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        content: Text(
          'هل أنت متأكد من حذف الغرفة "${room.title}"؟',
          style: GoogleFonts.cairo(),
        ),
        actions: [
          TextButton(
            onPressed: () => context.pop(),
            child: Text('إلغاء', style: GoogleFonts.cairo()),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () {
              setState(() {
                rooms.remove(room);
              });
              context.pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'تم حذف الغرفة: ${room.title}',
                    style: GoogleFonts.cairo(),
                  ),
                  backgroundColor: Colors.redAccent,
                ),
              );
            },
            child: Text('حذف', style: GoogleFonts.cairo(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'إدارة الغرف',
          style: GoogleFonts.cairo(
            fontWeight: FontWeight.bold,
            color: AppTheme.primaryColor,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: rooms.isEmpty
          ? Center(
              child: Text(
                'لا توجد غرف مضافة',
                style: GoogleFonts.cairo(
                  fontSize: 16,
                  color: AppTheme.greyColor,
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
              itemCount: rooms.length,
              itemBuilder: (context, index) {
                final room = rooms[index];
                return Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(13),
                  ),
                  elevation: 2,
                  color: Colors.white,
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        room.imageUrl,
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                        loadingBuilder: (context, child, loadingProgress) {
                          if (loadingProgress == null) return child;
                          return Container(
                            width: 50,
                            height: 50,
                            color: AppTheme.greyColor.withAlpha(51),
                            child: const Center(
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          );
                        },
                        errorBuilder: (ctx, e, s) => Container(
                          width: 50,
                          height: 50,
                          color: AppTheme.greyColor.withAlpha(51),
                          child: const Icon(Icons.image, color: Colors.grey),
                        ),
                      ),
                    ),
                    title: Text(
                      room.title,
                      style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      '${room.location} • ${room.pricePerNight} \$ / ليلة',
                      style: GoogleFonts.cairo(
                        fontSize: 14,
                        color: AppTheme.greyColor,
                      ),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      tooltip: 'حذف الغرفة',
                      onPressed: () => _confirmDeleteRoom(room),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
