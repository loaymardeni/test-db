import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../theme/app_theme.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'لوحة التحكم - المشرف',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _buildTile(
            context,
            icon: Icons.person,
            title: 'إدارة المستخدمين',
            onTap: () => Navigator.pushNamed(context, '/manage_users'),
          ),
          const SizedBox(height: 16),
          _buildTile(
            context,
            icon: Icons.check_circle,
            title: 'مراجعة الإعلانات قبل النشر',
            onTap: () => Navigator.pushNamed(context, '/review_listings'),
          ),
          const SizedBox(height: 16),
          _buildTile(
            context,
            icon: Icons.bar_chart,
            title: 'الإحصائيات العامة',
            onTap: () => Navigator.pushNamed(context, '/statistics'),
          ),
          const SizedBox(height: 16),
          _buildTile(
            context,
            icon: Icons.report,
            title: 'مراجعة الشكاوى',
            onTap: () => Navigator.pushNamed(context, '/complaints_review'),
          ),
        ],
      ),
    );
  }

  Widget _buildTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      elevation: 4,
      color: Colors.white,
      child: ListTile(
        leading: Icon(icon, size: 32, color: AppTheme.primaryColor),
        title: Text(
          title,
          style: GoogleFonts.cairo(
            fontSize: 18,
            color: Colors.black87,
            fontWeight: FontWeight.w600,
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios,
          color: AppTheme.greyColor,
          size: 22,
        ),
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 12,
        ),
      ),
    );
  }
}
