import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../theme/app_theme.dart';

class User {
  final String id;
  final String name;
  bool isActive;

  User({required this.id, required this.name, this.isActive = true});
}

class ManageUsersScreen extends StatefulWidget {
  const ManageUsersScreen({super.key});

  @override
  State<ManageUsersScreen> createState() => _ManageUsersScreenState();
}

class _ManageUsersScreenState extends State<ManageUsersScreen> {
  final List<User> _users = [
    User(id: 'u1', name: 'أحمد محمد', isActive: true),
    User(id: 'u2', name: 'سارة علي', isActive: false),
    User(id: 'u3', name: 'خالد سمير', isActive: true),
  ];

  void _toggleUserStatus(User user) {
    setState(() {
      user.isActive = !user.isActive;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          user.isActive
              ? 'تم تفعيل المستخدم ${user.name}'
              : 'تم حظر المستخدم ${user.name}',
          style: GoogleFonts.cairo(),
        ),
        backgroundColor: user.isActive ? Colors.green : Colors.redAccent,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'إدارة المستخدمين',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 21,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _users.length,
        separatorBuilder: (context, index) => const Divider(),
        itemBuilder: (context, index) {
          final user = _users[index];
          return Card(
            elevation: 3,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            color: Colors.white,
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: user.isActive
                    ? AppTheme.primaryColor
                    : AppTheme.greyColor,
                child: Text(
                  user.name.characters.first,
                  style: GoogleFonts.cairo(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              title: Text(
                user.name,
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              subtitle: Text(
                user.isActive ? 'نشط' : 'محظور',
                style: GoogleFonts.cairo(
                  color: user.isActive ? Colors.green : Colors.redAccent,
                ),
              ),
              trailing: TextButton.icon(
                icon: Icon(
                  user.isActive ? Icons.block : Icons.check_circle,
                  color: user.isActive ? Colors.redAccent : Colors.green,
                ),
                label: Text(
                  user.isActive ? 'حظر' : 'تفعيل',
                  style: GoogleFonts.cairo(
                    color: user.isActive ? Colors.redAccent : Colors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: TextButton.styleFrom(
                  foregroundColor: user.isActive
                      ? Colors.redAccent
                      : Colors.green,
                ),
                onPressed: () => _toggleUserStatus(user),
              ),
            ),
          );
        },
      ),
    );
  }
}
