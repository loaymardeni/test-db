import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../theme/app_theme.dart';

class ComplaintsReviewScreen extends StatelessWidget {
  const ComplaintsReviewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> complaints = [
      {
        'id': 'c1',
        'user': 'علي حسن',
        'issue': 'الغرفة لم تكن نظيفة كما هو معلن',
        'date': '2025-05-10',
      },
      {
        'id': 'c2',
        'user': 'منى سعيد',
        'issue': 'المضيف لم يرد على الرسائل',
        'date': '2025-05-12',
      },
      {
        'id': 'c3',
        'user': 'رامي يوسف',
        'issue': 'تم إلغاء الحجز دون إشعار مسبق',
        'date': '2025-05-14',
      },
    ];

    void showComplaintDetails(Map<String, String> comp) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text(
            'شكوى من ${comp['user']}',
            style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'المشكلة: ${comp['issue']}',
                style: GoogleFonts.cairo(fontSize: 16),
              ),
              const SizedBox(height: 8),
              Text(
                'التاريخ: ${comp['date']}',
                style: GoogleFonts.cairo(color: AppTheme.greyColor),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('إغلاق', style: GoogleFonts.cairo()),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryColor,
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      'تم اعتماد الشكوى',
                      style: GoogleFonts.cairo(),
                    ),
                    backgroundColor: AppTheme.primaryColor,
                  ),
                );
              },
              child: Text(
                'اعتماد',
                style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
              ),
            ),
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: AppTheme.primaryColor),
                foregroundColor: AppTheme.primaryColor,
              ),
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('تم رفض الشكوى', style: GoogleFonts.cairo()),
                    backgroundColor: Colors.redAccent,
                  ),
                );
              },
              child: Text(
                'رفض',
                style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'مراجعة الشكاوى',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: complaints.length,
        separatorBuilder: (ctx, i) => const SizedBox(height: 7),
        itemBuilder: (context, index) {
          final comp = complaints[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 5),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            elevation: 3,
            color: Colors.white,
            child: ListTile(
              title: Text(
                comp['user']!,
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: AppTheme.primaryColor,
                ),
              ),
              subtitle: Text(
                comp['issue']!,
                style: GoogleFonts.cairo(fontSize: 15, color: Colors.black87),
              ),
              trailing: Text(
                comp['date']!,
                style: GoogleFonts.cairo(
                  fontSize: 13,
                  color: AppTheme.greyColor,
                ),
              ),
              onTap: () => showComplaintDetails(comp),
              contentPadding: const EdgeInsets.symmetric(
                vertical: 12,
                horizontal: 16,
              ),
            ),
          );
        },
      ),
    );
  }
}
