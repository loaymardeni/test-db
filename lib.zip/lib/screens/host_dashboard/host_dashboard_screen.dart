import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import 'package:harbooq/theme/app_theme.dart';

class HostDashboardScreen extends StatelessWidget {
  const HostDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'لوحة المضيف',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 21,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          _buildTile(
            context,
            icon: Icons.home_work,
            title: 'إدارة الغرف',
            routeName: '/manage-rooms',
          ),
          const SizedBox(height: 12),
          _buildTile(
            context,
            icon: Icons.book_online,
            title: 'طلبات الحجز',
            routeName: '/booking-requests',
          ),
          const SizedBox(height: 12),
          _buildTile(
            context,
            icon: Icons.rate_review,
            title: 'المراجعات',
            routeName: '/reviews',
          ),
          const SizedBox(height: 12),
          _buildTile(
            context,
            icon: Icons.settings,
            title: 'إعدادات المضيف',
            routeName: '/host-settings',
          ),
        ],
      ),
    );
  }

  Widget _buildTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String routeName,
  }) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 4,
      color: Colors.white,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(
          vertical: 14,
          horizontal: 16,
        ),
        leading: Icon(icon, size: 32, color: AppTheme.primaryColor),
        title: Text(
          title,
          style: GoogleFonts.cairo(
            fontSize: 17,
            fontWeight: FontWeight.bold,
            color: AppTheme.primaryColor,
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios,
          color: AppTheme.greyColor,
          size: 18,
        ),
        onTap: () => context.push(routeName),
      ),
    );
  }
}
