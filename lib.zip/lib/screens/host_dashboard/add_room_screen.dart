import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/models/room_model.dart';
import 'package:harbooq/theme/app_theme.dart';
import 'package:uuid/uuid.dart';

class AddRoomScreen extends StatefulWidget {
  final Function(Room) onAdd;

  const AddRoomScreen({super.key, required this.onAdd});

  @override
  State<AddRoomScreen> createState() => _AddRoomScreenState();
}

class _AddRoomScreenState extends State<AddRoomScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _imageUrlController = TextEditingController();
  final TextEditingController _capacityController = TextEditingController();

  void _submit() {
    if (_formKey.currentState!.validate()) {
      final price = double.tryParse(_priceController.text);
      final capacity = int.tryParse(_capacityController.text);
      if (price == null || price <= 0) {
        _showError('الرجاء إدخال سعر صالح أكبر من صفر');
        return;
      }
      if (capacity == null || capacity <= 0) {
        _showError('الرجاء إدخال عدد أشخاص صالح أكبر من صفر');
        return;
      }

      final room = Room(
        id: const Uuid().v4(),
        title: _titleController.text.trim(),
        description: _descriptionController.text.trim(),
        location: _locationController.text.trim(),
        pricePerNight: price,
        imageUrl: _imageUrlController.text.trim(),
        capacity: capacity,
      );

      widget.onAdd(room);
      Navigator.pop(context);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message, style: GoogleFonts.cairo())),
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _locationController.dispose();
    _priceController.dispose();
    _imageUrlController.dispose();
    _capacityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'إضافة غرفة',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              _buildField(_titleController, 'عنوان الغرفة'),
              const SizedBox(height: 12),
              _buildField(_descriptionController, 'الوصف', maxLines: 3),
              const SizedBox(height: 12),
              _buildField(_locationController, 'الموقع'),
              const SizedBox(height: 12),
              _buildField(
                _priceController,
                'السعر لليلة',
                type: TextInputType.number,
              ),
              const SizedBox(height: 12),
              _buildField(
                _capacityController,
                'عدد الأشخاص',
                type: TextInputType.number,
              ),
              const SizedBox(height: 12),
              _buildField(_imageUrlController, 'رابط الصورة'),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                  onPressed: _submit,
                  child: Text(
                    'إضافة الغرفة',
                    style: GoogleFonts.cairo(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField(
    TextEditingController controller,
    String label, {
    int maxLines = 1,
    TextInputType type = TextInputType.text,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      keyboardType: type,
      style: GoogleFonts.cairo(fontSize: 16, color: Colors.black87),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: GoogleFonts.cairo(
          color: AppTheme.greyColor.withAlpha(217),
          fontWeight: FontWeight.w500,
        ),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 12,
        ),
      ),
      validator: (value) => (value == null || value.trim().isEmpty)
          ? 'الرجاء إدخال $label'
          : null,
    );
  }
}
