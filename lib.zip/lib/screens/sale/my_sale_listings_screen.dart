import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';
import '../../models/property.dart';

class MySaleListingsScreen extends StatefulWidget {
  const MySaleListingsScreen({super.key});

  @override
  State<MySaleListingsScreen> createState() => _MySaleListingsScreenState();
}

class _MySaleListingsScreenState extends State<MySaleListingsScreen> {
  List<Property> myListings = [
    Property(
      id: 's1',
      title: 'شقة فاخرة',
      location: 'دمشق – المزة',
      price: 120000,
      description: 'شقة أنيقة بمساحة 120م² مع إطلالة رائعة.',
      docsUrl: 'https://example.com/docs1.pdf',
      imageUrls: ['https://via.placeholder.com/150'],
    ),
    Property(
      id: 's2',
      title: 'فيلا واسعة',
      location: 'حمص – الحولة',
      price: 250000,
      description: 'فيلا فخمة بمسبح وحديقة خاصة.',
      docsUrl: 'https://example.com/docs2.pdf',
      imageUrls: ['https://via.placeholder.com/150'],
    ),
  ];

  void _viewDetails(Property listing) {
    Navigator.pushNamed(context, '/sale_details', arguments: listing);
  }

  void _editListing(Property listing) {
    Navigator.pushNamed(context, '/edit_sale', arguments: listing).then((_) {
      setState(() {});
    });
  }

  void _deleteListing(Property listing) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(
          'حذف الإعلان',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        content: Text(
          'هل أنت متأكد من حذف هذا الإعلان؟',
          style: GoogleFonts.cairo(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('إلغاء', style: GoogleFonts.cairo()),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () {
              setState(() => myListings.removeWhere((l) => l.id == listing.id));
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'تم حذف الإعلان بنجاح',
                    style: GoogleFonts.cairo(),
                  ),
                  backgroundColor: Colors.redAccent,
                ),
              );
            },
            child: Text('حذف', style: GoogleFonts.cairo(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'إعلاناتي المعروضة للبيع',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 21,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: myListings.isEmpty
          ? Center(
              child: Text(
                'لا توجد إعلانات للبيع حالياً',
                style: GoogleFonts.cairo(
                  fontSize: 18,
                  color: AppTheme.greyColor,
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: myListings.length,
              itemBuilder: (context, index) {
                final listing = myListings[index];
                final previewImage = listing.imageUrls.isNotEmpty
                    ? listing.imageUrls.first
                    : 'https://via.placeholder.com/150';

                return Card(
                  margin: const EdgeInsets.only(bottom: 13),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 4,
                  color: Colors.white,
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(13),
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        previewImage,
                        width: 60,
                        height: 60,
                        fit: BoxFit.cover,
                      ),
                    ),
                    title: Text(
                      listing.title,
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: AppTheme.primaryColor,
                      ),
                    ),
                    subtitle: Text(
                      '${listing.location} • ${listing.price.toStringAsFixed(0)} \$',
                      style: GoogleFonts.cairo(
                        fontSize: 14,
                        color: AppTheme.greyColor,
                      ),
                    ),
                    onTap: () => _viewDetails(listing),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit, color: AppTheme.primaryColor),
                          tooltip: 'تعديل الإعلان',
                          onPressed: () => _editListing(listing),
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.delete,
                            color: Colors.redAccent,
                          ),
                          tooltip: 'حذف الإعلان',
                          onPressed: () => _deleteListing(listing),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
