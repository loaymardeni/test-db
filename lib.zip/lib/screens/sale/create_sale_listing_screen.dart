import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uuid/uuid.dart';
import 'package:harbooq/theme/app_theme.dart';
import '../../models/property.dart';

class CreateSaleListingScreen extends StatefulWidget {
  final Function(Property) onCreate;

  const CreateSaleListingScreen({super.key, required this.onCreate});

  @override
  State<CreateSaleListingScreen> createState() =>
      _CreateSaleListingScreenState();
}

class _CreateSaleListingScreenState extends State<CreateSaleListingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _locationController = TextEditingController();
  final _priceController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _docsUrlController = TextEditingController();
  final _imagesController = TextEditingController();

  void _submit() {
    if (_formKey.currentState!.validate()) {
      final imageUrls = _imagesController.text
          .split(',')
          .map((url) => url.trim())
          .where((url) => url.isNotEmpty)
          .toList();

      final listing = Property(
        id: const Uuid().v4(),
        title: _titleController.text.trim(),
        location: _locationController.text.trim(),
        price: double.parse(_priceController.text),
        description: _descriptionController.text.trim(),
        docsUrl: _docsUrlController.text.trim(),
        imageUrls: imageUrls,
      );
      widget.onCreate(listing);
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _locationController.dispose();
    _priceController.dispose();
    _descriptionController.dispose();
    _docsUrlController.dispose();
    _imagesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'إنشاء إعلان للبيع',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 21,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              _buildField(_titleController, 'عنوان العقار'),
              const SizedBox(height: 12),
              _buildField(_locationController, 'الموقع'),
              const SizedBox(height: 12),
              _buildField(
                _priceController,
                'السعر',
                type: TextInputType.number,
              ),
              const SizedBox(height: 12),
              _buildField(_descriptionController, 'الوصف', maxLines: 3),
              const SizedBox(height: 12),
              _buildField(_docsUrlController, 'رابط الوثائق (PDF)'),
              const SizedBox(height: 12),
              _buildField(
                _imagesController,
                'روابط الصور (افصلها بفاصلة)',
                maxLines: 2,
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _submit,
                  icon: const Icon(Icons.upload_file),
                  label: Text(
                    'إنشاء الإعلان',
                    style: GoogleFonts.cairo(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField(
    TextEditingController controller,
    String label, {
    int maxLines = 1,
    TextInputType type = TextInputType.text,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      keyboardType: type,
      style: GoogleFonts.cairo(fontSize: 16, color: Colors.black87),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: GoogleFonts.cairo(
          color: AppTheme.greyColor.withAlpha(216),
          fontWeight: FontWeight.w500,
        ),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
      ),
      validator: (value) =>
          (value == null || value.trim().isEmpty) ? 'أدخل $label' : null,
    );
  }
}
