import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class UploadLegalDocsScreen extends StatefulWidget {
  final String listingId;
  const UploadLegalDocsScreen({super.key, required this.listingId});

  @override
  State<UploadLegalDocsScreen> createState() => _UploadLegalDocsScreenState();
}

class _UploadLegalDocsScreenState extends State<UploadLegalDocsScreen> {
  File? _selectedFile;
  UploadTask? _uploadTask;
  bool _isUploading = false;

  Future<void> _pickDocument() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (result != null && result.files.single.path != null) {
      setState(() {
        _selectedFile = File(result.files.single.path!);
      });
    }
  }

  Future<void> _uploadFile() async {
    if (_selectedFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('الرجاء اختيار ملف أولاً', style: GoogleFonts.cairo()),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    setState(() {
      _isUploading = true;
    });

    try {
      final ref = FirebaseStorage.instance.ref(
        'legal_docs/${widget.listingId}/${DateTime.now().millisecondsSinceEpoch}.pdf',
      );
      _uploadTask = ref.putFile(_selectedFile!);

      final snapshot = await _uploadTask!;
      final downloadUrl = await snapshot.ref.getDownloadURL();

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'تم رفع المستند: ${_selectedFile!.path.split('/').last}',
            style: GoogleFonts.cairo(),
          ),
          backgroundColor: AppTheme.primaryColor,
        ),
      );
      setState(() {
        _selectedFile = null;
      });
      Navigator.of(context).pop(downloadUrl);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('حدث خطأ أثناء الرفع: $e', style: GoogleFonts.cairo()),
          backgroundColor: Colors.redAccent,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isUploading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('رفع الوثائق القانونية', style: GoogleFonts.cairo()),
        backgroundColor: AppTheme.primaryColor,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ElevatedButton.icon(
              onPressed: _isUploading ? null : _pickDocument,
              icon: const Icon(Icons.attach_file),
              label: Text('اختيار ملف PDF', style: GoogleFonts.cairo()),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryColor,
                foregroundColor: Colors.white,
              ),
            ),
            const SizedBox(height: 20),
            if (_selectedFile != null)
              Card(
                color: Colors.grey[100],
                child: ListTile(
                  leading: const Icon(Icons.picture_as_pdf, color: Colors.red),
                  title: Text(_selectedFile!.path.split('/').last),
                  trailing: IconButton(
                    icon: const Icon(Icons.close, color: Colors.grey),
                    onPressed: _isUploading
                        ? null
                        : () => setState(() => _selectedFile = null),
                  ),
                ),
              ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isUploading ? null : _uploadFile,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryColor,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: _isUploading
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(width: 12),
                          Text('جاري الرفع...'),
                        ],
                      )
                    : Text('رفع الملف', style: GoogleFonts.cairo(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
