import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import 'package:harbooq/theme/app_theme.dart';
import '../../models/property.dart';

class BrowseForSaleScreen extends StatelessWidget {
  const BrowseForSaleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Property> forSale = [
      Property(
        id: 'p1',
        title: 'شقة فاخرة للبيع',
        location: 'دمشق – المزة',
        price: 120000,
        description: 'شقة مساحتها 120م²، تشطيب سوبر ديلوكس، قريبة من الخدمات.',
        docsUrl: 'https://example.com/docs1.pdf',
        imageUrls: ['https://via.placeholder.com/150'],
      ),
      Property(
        id: 'p2',
        title: 'فيلا واسعة',
        location: 'حمص – الحولة',
        price: 250000,
        description: 'فيلا بمساحة 350م² مع حديقة خاصة ومسبح.',
        docsUrl: 'https://example.com/docs2.pdf',
        imageUrls: ['https://via.placeholder.com/150'],
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'تصفح عقارات للبيع',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: forSale.length,
        itemBuilder: (context, index) {
          final item = forSale[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
            ),
            elevation: 4,
            color: Colors.white,
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(
                vertical: 10,
                horizontal: 16,
              ),
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: item.imageUrls.isNotEmpty
                    ? Image.network(
                        item.imageUrls.first,
                        width: 60,
                        height: 60,
                        fit: BoxFit.cover,
                      )
                    : Container(
                        width: 60,
                        height: 60,
                        color: AppTheme.accentColor.withAlpha(31),
                        child: const Icon(
                          Icons.home_work,
                          color: Colors.grey,
                          size: 34,
                        ),
                      ),
              ),
              title: Text(
                item.title,
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.bold,
                  fontSize: 17,
                  color: AppTheme.primaryColor,
                ),
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  '${item.location} • ${item.price.toStringAsFixed(0)} \$',
                  style: GoogleFonts.cairo(fontSize: 15, color: Colors.black87),
                ),
              ),
              onTap: () {
                context.push('/sale_details', extra: item);
              },
            ),
          );
        },
      ),
    );
  }
}
