import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class ChatSettingsScreen extends StatefulWidget {
  const ChatSettingsScreen({super.key});

  @override
  State<ChatSettingsScreen> createState() => _ChatSettingsScreenState();
}

class _ChatSettingsScreenState extends State<ChatSettingsScreen> {
  bool soundEnabled = true;
  bool highlightMessages = true;
  bool allowReplies = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'إعدادات الدردشة',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
        backgroundColor: AppTheme.backgroundColor,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _buildSettingItem(
            title: 'تشغيل صوت الإشعارات',
            value: soundEnabled,
            onChanged: (val) => setState(() => soundEnabled = val),
          ),
          const SizedBox(height: 16),
          _buildSettingItem(
            title: 'تمييز الرسائل المرسلة بلون مختلف',
            value: highlightMessages,
            onChanged: (val) => setState(() => highlightMessages = val),
          ),
          const SizedBox(height: 16),
          _buildSettingItem(
            title: 'السماح بالردود السريعة',
            value: allowReplies,
            onChanged: (val) => setState(() => allowReplies = val),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingItem({
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: SwitchListTile(
        title: Text(
          title,
          style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w500),
        ),
        value: value,
        activeColor: AppTheme.primaryColor,
        onChanged: onChanged,
      ),
    );
  }
}
