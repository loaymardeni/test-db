import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class ChatsScreen extends StatelessWidget {
  const ChatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'الرسائل',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        centerTitle: true,
        backgroundColor: AppTheme.backgroundColor,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 18),
        itemCount: 5,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            elevation: 3,
            color: Colors.white,
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(
                vertical: 10,
                horizontal: 16,
              ),
              leading: CircleAvatar(
                radius: 25,
                backgroundColor: AppTheme.primaryColor,
                child: const Icon(Icons.person, color: Colors.white, size: 28),
              ),
              title: Text(
                'اسم المستخدم ${index + 1}',
                style: GoogleFonts.cairo(
                  color: AppTheme.primaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              subtitle: Text(
                'آخر رسالة تم إرسالها...',
                style: GoogleFonts.cairo(
                  color: AppTheme.greyColor,
                  fontSize: 14,
                ),
              ),
              trailing: Icon(
                Icons.arrow_forward_ios,
                size: 18,
                color: AppTheme.greyColor,
              ),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      'قريباً سيتم فتح تفاصيل الرسالة',
                      style: GoogleFonts.cairo(),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
