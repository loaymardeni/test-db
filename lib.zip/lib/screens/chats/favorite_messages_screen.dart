import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class FavoriteMessagesScreen extends StatelessWidget {
  // حالياً قائمة وهمية لحين ربط Firebase
  final List<String> _mockFavorites = const [
    'مرحبا، كيف بقدر ساعدك؟',
    'تم تأكيد الحجز بنجاح ✅',
    'سيتم التواصل معك قريباً.',
    'شكراً لتفهمك 🌸',
  ];

  const FavoriteMessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'الرسائل المفضلة',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
        backgroundColor: AppTheme.backgroundColor,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: _mockFavorites.isEmpty
          ? Center(
              child: Text(
                'لا توجد رسائل مفضلة بعد.',
                style: GoogleFonts.cairo(color: Colors.grey, fontSize: 16),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _mockFavorites.length,
              itemBuilder: (context, index) {
                return Container(
                  margin: const EdgeInsets.symmetric(vertical: 6),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Text(
                    _mockFavorites[index],
                    style: GoogleFonts.cairo(fontSize: 15),
                  ),
                );
              },
            ),
    );
  }
}
