import 'package:flutter/material.dart';

class CarRentFormScreen extends StatelessWidget {
  const CarRentFormScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدخال معلومات السيارة')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _field('نوع السيارة'),
            _field('الموديل'),
            _field('سنة الصنع', keyboardType: TextInputType.number),
            _field('عدد الركاب', keyboardType: TextInputType.number),
            _field(
              'السعر اليومي (ليرة سورية)',
              keyboardType: TextInputType.number,
            ),
            _field('ملاحظات إضافية', maxLines: 3),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                // تابع للخطوة التالية
              },
              child: const Text('متابعة'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(String label, {TextInputType? keyboardType, int maxLines = 1}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 15)),
        const SizedBox(height: 6),
        TextField(
          keyboardType: keyboardType,
          maxLines: maxLines,
          decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 10,
            ),
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}
