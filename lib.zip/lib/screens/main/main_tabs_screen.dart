import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../home/home_screen.dart';
import '../favorites/favorites_screen.dart';
import '../bookings/my_bookings_screen.dart';
import '../profile/profile_dashboard_screen.dart';
import '../../widgets/main_bottom_nav.dart';
import '../../widgets/smart_add_sheet.dart';

class MainTabsScreen extends StatefulWidget {
  const MainTabsScreen({super.key});

  @override
  State<MainTabsScreen> createState() => _MainTabsScreenState();
}

class _MainTabsScreenState extends State<MainTabsScreen> {
  int _currentIndex = 0;
  Offset fabPosition = const Offset(300, 550);

  final List<Widget> _pages = const [
    HomeScreen(),
    FavoritesScreen(),
    MyBookingsScreen(),
    ProfileDashboardScreen(),
  ];

  void _handleTabChange(int index) {
    setState(() => _currentIndex = index);
  }

  void _handleAddPressed() {
    final bottomSheetContext = context;

    showModalBottomSheet(
      context: bottomSheetContext,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      isScrollControlled: true,
      builder: (context) {
        return SmartAddSheet(
          onSelect: (action) async {
            Navigator.of(context).pop();

            await Future.delayed(const Duration(milliseconds: 100));

            if (!bottomSheetContext.mounted) return;

            switch (action) {
              case 'sell_property':
                bottomSheetContext.push('/add/sell');
                break;
              case 'rent_property':
                bottomSheetContext.push('/add/rent');
                break;
              case 'rent_car':
                bottomSheetContext.push('/add/car');
                break;
              case 'offer_service':
                bottomSheetContext.push('/add/service');
                break;
            }
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop && _currentIndex != 0) {
          setState(() => _currentIndex = 0);
        }
      },
      child: Scaffold(
        body: Stack(
          children: [
            IndexedStack(index: _currentIndex, children: _pages),
            Positioned(
              left: fabPosition.dx,
              top: fabPosition.dy,
              child: Draggable(
                feedback: _buildChatButton(),
                childWhenDragging: const SizedBox(),
                onDragEnd: (details) {
                  setState(() {
                    final screenSize = MediaQuery.of(context).size;
                    fabPosition = Offset(
                      details.offset.dx.clamp(0.0, screenSize.width - 70),
                      details.offset.dy.clamp(0.0, screenSize.height - 150),
                    );
                  });
                },
                child: _buildChatButton(),
              ),
            ),
          ],
        ),
        bottomNavigationBar: MainBottomNav(
          current: _currentIndex,
          onTabChanged: _handleTabChange,
          onAddPressed: _handleAddPressed,
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: _handleAddPressed,
          backgroundColor: Colors.pink,
          elevation: 6,
          shape: const CircleBorder(),
          child: const Icon(Icons.add, size: 28),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      ),
    );
  }

  Widget _buildChatButton() {
    return FloatingActionButton(
      onPressed: () => context.push('/chats/support'),
      backgroundColor: const Color.fromRGBO(255, 255, 255, 0.9),
      shape: const CircleBorder(),
      elevation: 6,
      child: const Icon(Icons.smart_toy_outlined, color: Colors.pink),
    );
  }
}
