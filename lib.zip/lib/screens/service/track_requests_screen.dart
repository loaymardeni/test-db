import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class TrackRequestsScreen extends StatefulWidget {
  const TrackRequestsScreen({super.key});

  @override
  State<TrackRequestsScreen> createState() => _TrackRequestsScreenState();
}

class _TrackRequestsScreenState extends State<TrackRequestsScreen> {
  List<Map<String, String>> requests = [
    {
      'service': 'تأجير عقار',
      'status': 'قيد المراجعة',
      'date': '2024-05-15',
      'details': 'طلبك قيد المراجعة من قبل الفريق المختص.',
    },
    {
      'service': 'بيع عقار',
      'status': 'تم القبول',
      'date': '2024-05-10',
      'details': 'تم قبول طلب البيع وسيتم التواصل معك قريباً.',
    },
    {
      'service': 'تأجير عقار',
      'status': 'مرفوض',
      'date': '2024-04-28',
      'details': 'تم رفض طلبك بسبب نقص المستندات المطلوبة.',
    },
  ];

  Color getStatusColor(String status) {
    switch (status) {
      case 'تم القبول':
        return Colors.green;
      case 'قيد المراجعة':
        return Colors.orange;
      case 'مرفوض':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  void _refreshRequests() {
    setState(() {
      requests = List.from(requests);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تم تحديث الطلبات', style: GoogleFonts.cairo()),
        backgroundColor: AppTheme.primaryColor,
      ),
    );
  }

  void _showRequestDetails(Map<String, String> request) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              request['service'] ?? '',
              style: GoogleFonts.cairo(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryColor,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              request['details'] ?? 'لا توجد تفاصيل متاحة.',
              style: GoogleFonts.cairo(fontSize: 16),
            ),
            const SizedBox(height: 20),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('إغلاق', style: GoogleFonts.cairo(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: Text(
          'متابعة طلباتي',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        backgroundColor: AppTheme.primaryColor,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'تحديث الطلبات',
            onPressed: _refreshRequests,
          ),
        ],
      ),
      body: requests.isEmpty
          ? Center(
              child: Text(
                'لا توجد طلبات حالياً.',
                style: GoogleFonts.cairo(fontSize: 18, color: Colors.grey),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: requests.length,
              itemBuilder: (context, index) {
                final request = requests[index];
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  elevation: 3,
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(
                      vertical: 10,
                      horizontal: 14,
                    ),
                    leading: CircleAvatar(
                      radius: 20,
                      backgroundColor: getStatusColor(
                        request['status']!,
                      ).withAlpha((0.1 * 255).round()),
                      child: Icon(
                        Icons.assignment,
                        color: getStatusColor(request['status']!),
                      ),
                    ),
                    title: Text(
                      request['service']!,
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    subtitle: Text(
                      'تاريخ التقديم: ${request['date']}',
                      style: GoogleFonts.cairo(),
                    ),
                    trailing: Text(
                      request['status']!,
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.bold,
                        color: getStatusColor(request['status']!),
                      ),
                    ),
                    onTap: () => _showRequestDetails(request),
                  ),
                );
              },
            ),
    );
  }
}
