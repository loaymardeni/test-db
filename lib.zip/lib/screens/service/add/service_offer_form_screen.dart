import 'package:flutter/material.dart';

class ServiceOfferFormScreen extends StatelessWidget {
  const ServiceOfferFormScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تقديم خدمة')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _field('عنوان الخدمة'),
            _field('نوع الخدمة'),
            _field('السعر (ليرة سورية)', keyboardType: TextInputType.number),
            _field('تفاصيل الخدمة', maxLines: 4),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                // تنفيذ عند المتابعة
              },
              child: const Text('متابعة'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(String label, {TextInputType? keyboardType, int maxLines = 1}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 15)),
        const SizedBox(height: 6),
        TextField(
          keyboardType: keyboardType,
          maxLines: maxLines,
          decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 10,
            ),
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}
