import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ReportContentScreen extends StatelessWidget {
  const ReportContentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'الإبلاغ عن محتوى',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Text(
          '''إذا صادفت أي محتوى مخالف أو غير لائق داخل التطبيق، يمكنك التواصل معنا مباشرة عبر:

📩 البريد: loay_mardeni@hotmail.com  
📞 رقم الهاتف: 0489126332

يرجى وصف المشكلة بدقة، وسنقوم بمراجعتها خلال 48 ساعة.  
نشكرك لمساهمتك في جعل المنصة آمنة للجميع.''',
          style: GoogleFonts.cairo(fontSize: 15, height: 1.7),
          textAlign: TextAlign.justify,
        ),
      ),
    );
  }
}
