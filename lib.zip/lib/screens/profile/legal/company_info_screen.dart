import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CompanyInfoScreen extends StatelessWidget {
  const CompanyInfoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'بيانات الشركة',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Text(
          '''اسم التطبيق: حربوق – Harbooq  
المطور: لؤي مارديني  
بلد التأسيس: بلجيكا  
البريد الإلكتروني للدعم: loay_mardeni@hotmail.com  
رقم الهاتف: 0489126332

هذا التطبيق مستقل وغير تابع لأي جهة رسمية أو حكومية.''',
          style: GoogleFonts.cairo(fontSize: 15, height: 1.7),
        ),
      ),
    );
  }
}
