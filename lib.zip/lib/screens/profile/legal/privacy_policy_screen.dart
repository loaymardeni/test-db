import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'سياسة الخصوصية',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Text(
            '''
نحن نحترم خصوصيتك ونلتزم بحماية بياناتك.

١. نقوم بجمع بعض البيانات الشخصية، مثل:
  - رقم الهاتف
  - البريد الإلكتروني
  - الموقع الجغرافي (اختياري)

٢. يتم استخدام هذه البيانات فقط لتحسين تجربة المستخدم داخل التطبيق، مثل:
  - تسهيل عمليات الحجز والتواصل
  - تخصيص المحتوى والعروض

٣. لا تتم مشاركة بياناتك مع أي جهة خارجية بدون موافقة صريحة منك، إلا في الحالات التي يطلبها القانون أو لحماية حقوق المستخدمين.

٤. يحق لك طلب تعديل أو حذف بياناتك في أي وقت عبر التواصل مع فريق الدعم على البريد التالي:
loay_mardeni@hotmail.com

٥. باستخدامك للتطبيق، فإنك توافق على سياسة الخصوصية هذه، ويحق لنا تعديلها في أي وقت، وسيتم إعلامك بالتغييرات عند الضرورة.

نشكرك على ثقتك.
''',
            style: GoogleFonts.cairo(fontSize: 15, height: 1.7),
            textAlign: TextAlign.justify,
          ),
        ),
      ),
    );
  }
}
