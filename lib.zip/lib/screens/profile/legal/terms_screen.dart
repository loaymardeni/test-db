import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'بنود الخدمة',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Text(
            '''
مرحبًا بك في تطبيق "حربوق"! نحن نحرص على تقديم تجربة آمنة وموثوقة لجميع المستخدمين. باستخدامك لهذا التطبيق، فإنك توافق على الشروط التالية:

١. **الاستخدام المشروع**  
يحظر استخدام التطبيق لأي أغراض غير قانونية أو ضارة أو تنتهك حقوق الآخرين، سواء داخل سوريا أو خارجها.

٢. **المحتوى والمسؤولية**  
أنت المسؤول الوحيد عن أي محتوى تقوم بنشره أو مشاركته. ويحق لإدارة التطبيق إزالة أي محتوى مخالف أو مضر دون إشعار مسبق.

٣. **حقوق الإدارة**  
يحق لإدارة "حربوق" تعليق أو إنهاء أي حساب ينتهك الشروط، بشكل مؤقت أو دائم، دون أي التزام بالتعويض.

٤. **حماية البيانات**  
نلتزم بالحفاظ على خصوصيتك، وفق ما هو موضح في سياسة الخصوصية. يرجى قراءتها بعناية.

٥. **التحديثات**  
نحتفظ بالحق في تعديل بنود هذه الاتفاقية في أي وقت. سيتم إعلامك بالتغييرات عبر التطبيق أو البريد الإلكتروني.

٦. **حل النزاعات**  
في حال حدوث أي نزاع قانوني، يتم التعامل معه بموجب القوانين المعمول بها في بلجيكا أو بلد إقامة المطوّر، ما لم يُتفق على خلاف ذلك.

نشكرك على استخدامك لتطبيق "حربوق"، ونأمل أن يكون عند حسن ظنك دائماً.
''',
            style: GoogleFonts.cairo(fontSize: 15, height: 1.7),
            textAlign: TextAlign.justify,
          ),
        ),
      ),
    );
  }
}
