import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'قانوني',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        children: [
          _buildLegalTile(
            context,
            title: 'بنود الخدمة',
            icon: Icons.rule_outlined,
            route: '/terms',
          ),
          _buildLegalTile(
            context,
            title: 'سياسة الخصوصية',
            icon: Icons.privacy_tip_outlined,
            route: '/privacy-policy',
          ),
          _buildLegalTile(
            context,
            title: 'بيانات الشركة',
            icon: Icons.info_outline,
            route: '/company-info',
          ),
          _buildLegalTile(
            context,
            title: 'الإبلاغ عن محتوى مخالف',
            icon: Icons.report_gmailerrorred_outlined,
            route: '/report-content',
          ),
        ],
      ),
    );
  }

  Widget _buildLegalTile(
    BuildContext context, {
    required String title,
    required IconData icon,
    required String route,
  }) {
    return ListTile(
      leading: Icon(icon, color: Colors.grey[800]),
      title: Text(
        title,
        style: GoogleFonts.cairo(fontSize: 15, fontWeight: FontWeight.w500),
      ),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: () => context.push(route),
    );
  }
}
