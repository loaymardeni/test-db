import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ReferHostScreen extends StatelessWidget {
  const ReferHostScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'إحالة مضيف',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
      ),
      body: Center(
        child: Text(
          'يمكنك دعوة صديق ليصبح مضيفًا!',
          style: GoogleFonts.cairo(fontSize: 16),
        ),
      ),
    );
  }
}
