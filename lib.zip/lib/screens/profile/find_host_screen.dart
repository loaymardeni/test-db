import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class FindHostScreen extends StatelessWidget {
  const FindHostScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'العثور على مضيف مشارك',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
        centerTitle: true,
      ),
      body: Center(
        child: Text(
          'ابحث عن مضيف بناءً على الموقع أو التقييم.',
          style: GoogleFonts.cairo(fontSize: 16),
        ),
      ),
    );
  }
}
