import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  // الدفع المحلي
  bool mtnEnabled = true;
  bool syriatelEnabled = false;
  bool syriaCashEnabled = false;
  bool codEnabled = true; // الدفع عند الاستلام

  // الدفع العالمي (جاهز للمستقبل)
  bool visaEnabled = false;
  bool masterCardEnabled = false;
  bool paypalEnabled = false;

  final TextEditingController mtnNumberController = TextEditingController();
  final TextEditingController syriaCashIdController = TextEditingController();

  @override
  void dispose() {
    mtnNumberController.dispose();
    syriaCashIdController.dispose();
    super.dispose();
  }

  Widget _buildPaymentTile({
    required String title,
    required bool value,
    required Function(bool) onChanged,
    Widget? trailing,
  }) {
    return SwitchListTile(
      title: Text(title, style: GoogleFonts.cairo()),
      value: value,
      onChanged: onChanged,
      secondary: const Icon(Icons.payment_outlined),
      subtitle: trailing,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'طرق الدفع',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'اختر وسائل الدفع التي تريد تفعيلها ضمن حسابك أو ممتلكاتك:',
            style: GoogleFonts.cairo(fontSize: 16),
          ),

          const SizedBox(height: 24),
          Text(
            '💳 الدفع المحلي',
            style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
          ),
          const Divider(),

          _buildPaymentTile(
            title: 'MTN Cash',
            value: mtnEnabled,
            onChanged: (val) => setState(() => mtnEnabled = val),
            trailing: mtnEnabled
                ? Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: TextField(
                      controller: mtnNumberController,
                      decoration: const InputDecoration(
                        hintText: 'رقم حساب MTN',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  )
                : null,
          ),

          _buildPaymentTile(
            title: 'Syriatel Cash',
            value: syriatelEnabled,
            onChanged: (val) => setState(() => syriatelEnabled = val),
          ),

          _buildPaymentTile(
            title: 'SyriaCash',
            value: syriaCashEnabled,
            onChanged: (val) => setState(() => syriaCashEnabled = val),
            trailing: syriaCashEnabled
                ? Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: TextField(
                      controller: syriaCashIdController,
                      decoration: const InputDecoration(
                        hintText: 'معرّف سوريا كاش',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  )
                : null,
          ),

          _buildPaymentTile(
            title: 'الدفع عند الاستلام',
            value: codEnabled,
            onChanged: (val) => setState(() => codEnabled = val),
          ),

          const SizedBox(height: 24),
          Text(
            '🌍 الدفع العالمي (قريبًا)',
            style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
          ),
          const Divider(),

          _buildPaymentTile(
            title: 'Visa',
            value: visaEnabled,
            onChanged: (val) => setState(() => visaEnabled = val),
          ),
          _buildPaymentTile(
            title: 'MasterCard',
            value: masterCardEnabled,
            onChanged: (val) => setState(() => masterCardEnabled = val),
          ),
          _buildPaymentTile(
            title: 'PayPal',
            value: paypalEnabled,
            onChanged: (val) => setState(() => paypalEnabled = val),
          ),
        ],
      ),
    );
  }
}
