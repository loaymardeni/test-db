import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';

import '../../../theme/app_theme.dart';

class AccountSettingsScreen extends StatelessWidget {
  const AccountSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: Text(
          'إعدادات الحساب',
          style: GoogleFonts.cairo(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black87),
        elevation: 0.5,
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 12),
        children: [
          _settingTile(Icons.person_outline, 'المعلومات الشخصية', () {
            context.push('/account_settings/personal_info');
          }),
          _settingTile(Icons.security, 'تسجيل الدخول والأمان', () {
            context.push('/account_settings/login_security');
          }),
          _settingTile(Icons.privacy_tip_outlined, 'الخصوصية', () {
            context.push('/account_settings/privacy');
          }),
          _settingTile(Icons.notifications_outlined, 'الإشعارات', () {
            context.push('/account_settings/notifications');
          }),
          _settingTile(Icons.credit_card_outlined, 'الدفعات', () {
            context.push('/account_settings/payments');
          }),
          _settingTile(Icons.settings_accessibility, 'سهولة الوصول', () {
            context.push('/account_settings/accessibility');
          }),
        ],
      ),
    );
  }

  Widget _settingTile(IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: Colors.black87),
      title: Text(
        title,
        style: GoogleFonts.cairo(fontSize: 15, fontWeight: FontWeight.w500),
      ),
      trailing: const Icon(Icons.chevron_left),
      onTap: onTap,
    );
  }
}
