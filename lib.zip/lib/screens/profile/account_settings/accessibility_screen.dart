import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AccessibilityScreen extends StatefulWidget {
  const AccessibilityScreen({super.key});

  @override
  State<AccessibilityScreen> createState() => _AccessibilityScreenState();
}

class _AccessibilityScreenState extends State<AccessibilityScreen> {
  bool highContrast = false;
  bool largeText = false;
  bool simpleMode = false;
  bool hapticFeedback = true;
  bool voiceDescriptions = false; // مستقبلاً

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'سهولة الوصول',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'خيارات تسهّل استخدام التطبيق بحسب احتياجاتك:',
            style: GoogleFonts.cairo(fontSize: 16),
          ),

          const SizedBox(height: 24),
          SwitchListTile(
            title: const Text('تباين عالي للألوان'),
            subtitle: const Text('الوضع المثالي لضعاف البصر'),
            value: highContrast,
            onChanged: (val) => setState(() => highContrast = val),
            secondary: const Icon(Icons.visibility),
          ),
          SwitchListTile(
            title: const Text('تكبير الخط داخل التطبيق'),
            subtitle: const Text('يُظهر النصوص بحجم أكبر قليلاً'),
            value: largeText,
            onChanged: (val) => setState(() => largeText = val),
            secondary: const Icon(Icons.format_size),
          ),
          SwitchListTile(
            title: const Text('واجهة مبسّطة'),
            subtitle: const Text('تخفي التفاصيل غير الضرورية'),
            value: simpleMode,
            onChanged: (val) => setState(() => simpleMode = val),
            secondary: const Icon(Icons.layers_clear),
          ),
          SwitchListTile(
            title: const Text('الاهتزاز عند الضغط'),
            subtitle: const Text('تشغيل أو إيقاف اهتزاز الأزرار'),
            value: hapticFeedback,
            onChanged: (val) => setState(() => hapticFeedback = val),
            secondary: const Icon(Icons.vibration),
          ),
          SwitchListTile(
            title: const Text('الوصف الصوتي (قريبًا)'),
            subtitle: const Text('قراءة المحتوى صوتياً للمستخدمين'),
            value: voiceDescriptions,
            onChanged: null, // غير مفعّل حالياً
            secondary: const Icon(Icons.volume_up),
          ),
        ],
      ),
    );
  }
}
