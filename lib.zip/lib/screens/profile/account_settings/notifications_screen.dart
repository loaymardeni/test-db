import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/services/notification_settings_service.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  // القيم الافتراضية
  bool loginNotification = true;
  bool passwordChangeNotification = true;
  bool failedLoginAttempt = false;

  bool messageNotification = true;
  bool bookingRequestNotification = true;
  bool reviewNotification = true;
  bool policyUpdateNotification = false;

  bool emailNotifications = true;
  bool pushNotifications = true;
  bool allNotifications = true;

  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await NotificationSettingsService.loadAllSettings();
    setState(() {
      loginNotification = settings['login']!;
      passwordChangeNotification = settings['passwordChange']!;
      failedLoginAttempt = settings['failedLogin']!;

      messageNotification = settings['message']!;
      bookingRequestNotification = settings['booking']!;
      reviewNotification = settings['review']!;
      policyUpdateNotification = settings['policy']!;

      emailNotifications = settings['email']!;
      pushNotifications = settings['push']!;
      allNotifications = settings['all']!;

      _isLoading = false;
    });
  }

  Future<void> _updateSetting(String key, bool value) async {
    await NotificationSettingsService.setNotification(key, value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'الإشعارات',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(
                  'تحكم بالإشعارات التي ترغب باستلامها على حسابك.',
                  style: GoogleFonts.cairo(fontSize: 16),
                ),
                const SizedBox(height: 24),

                Text(
                  'الإشعارات العامة',
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('تسجيل الدخول من جهاز جديد'),
                  value: loginNotification,
                  onChanged: (val) {
                    setState(() => loginNotification = val);
                    _updateSetting('login', val);
                  },
                ),
                SwitchListTile(
                  title: const Text('تغيير كلمة المرور أو الإيميل'),
                  value: passwordChangeNotification,
                  onChanged: (val) {
                    setState(() => passwordChangeNotification = val);
                    _updateSetting('passwordChange', val);
                  },
                ),
                SwitchListTile(
                  title: const Text('محاولات تسجيل دخول فاشلة'),
                  value: failedLoginAttempt,
                  onChanged: (val) {
                    setState(() => failedLoginAttempt = val);
                    _updateSetting('failedLogin', val);
                  },
                ),

                const SizedBox(height: 24),
                Text(
                  'نشاطات داخل التطبيق',
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('وصول رسالة من مستخدم'),
                  value: messageNotification,
                  onChanged: (val) {
                    setState(() => messageNotification = val);
                    _updateSetting('message', val);
                  },
                ),
                SwitchListTile(
                  title: const Text('طلب حجز أو شراء جديد'),
                  value: bookingRequestNotification,
                  onChanged: (val) {
                    setState(() => bookingRequestNotification = val);
                    _updateSetting('booking', val);
                  },
                ),
                SwitchListTile(
                  title: const Text('وصول تقييم جديد'),
                  value: reviewNotification,
                  onChanged: (val) {
                    setState(() => reviewNotification = val);
                    _updateSetting('review', val);
                  },
                ),
                SwitchListTile(
                  title: const Text('تحديثات سياسة الخصوصية'),
                  value: policyUpdateNotification,
                  onChanged: (val) {
                    setState(() => policyUpdateNotification = val);
                    _updateSetting('policy', val);
                  },
                ),

                const SizedBox(height: 24),
                Text(
                  'نوع الإشعار',
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('إشعارات عبر البريد الإلكتروني'),
                  value: emailNotifications,
                  onChanged: (val) {
                    setState(() => emailNotifications = val);
                    _updateSetting('email', val);
                  },
                ),
                SwitchListTile(
                  title: const Text('إشعارات على الهاتف (Push)'),
                  value: pushNotifications,
                  onChanged: (val) {
                    setState(() => pushNotifications = val);
                    _updateSetting('push', val);
                  },
                ),
                SwitchListTile(
                  title: const Text('إيقاف جميع الإشعارات'),
                  value: allNotifications,
                  onChanged: (val) {
                    setState(() => allNotifications = val);
                    _updateSetting('all', val);
                  },
                ),
              ],
            ),
    );
  }
}
