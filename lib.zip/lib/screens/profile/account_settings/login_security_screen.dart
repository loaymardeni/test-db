import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class LoginSecurityScreen extends StatefulWidget {
  const LoginSecurityScreen({super.key});

  @override
  State<LoginSecurityScreen> createState() => _LoginSecurityScreenState();
}

class _LoginSecurityScreenState extends State<LoginSecurityScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  void _showVerificationDialog(String type) {
    showDialog(
      context: context,
      builder: (context) {
        final codeController = TextEditingController();
        return AlertDialog(
          title: Text('تأكيد $type', style: GoogleFonts.cairo()),
          content: TextField(
            controller: codeController,
            decoration: InputDecoration(
              hintText: 'أدخل رمز التحقق',
              hintStyle: GoogleFonts.cairo(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('إلغاء', style: GoogleFonts.cairo()),
            ),
            ElevatedButton(
              onPressed: () {
                // تنفيذ عملية التأكيد هنا
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('$type تم تغييره بنجاح')),
                );
              },
              child: Text('تأكيد', style: GoogleFonts.cairo()),
            ),
          ],
        );
      },
    );
  }

  Widget _buildChangeTile(
    String label,
    IconData icon,
    TextEditingController controller,
    String type,
  ) {
    return ListTile(
      leading: Icon(icon, color: AppTheme.primaryColor),
      title: Text(label, style: GoogleFonts.cairo(fontSize: 16)),
      subtitle: TextField(
        controller: controller,
        style: GoogleFonts.cairo(),
        decoration: InputDecoration(
          hintText: 'أدخل $label الجديد',
          hintStyle: GoogleFonts.cairo(),
        ),
      ),
      trailing: ElevatedButton(
        onPressed: () => _showVerificationDialog(type),
        child: Text('تغيير', style: GoogleFonts.cairo(fontSize: 13)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: Text(
          'تسجيل الدخول والأمان',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
        elevation: 0.5,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildChangeTile(
            'البريد الإلكتروني',
            Icons.email,
            emailController,
            'البريد الإلكتروني',
          ),
          const Divider(),
          _buildChangeTile(
            'رقم الهاتف',
            Icons.phone,
            phoneController,
            'رقم الهاتف',
          ),
          const Divider(),
          _buildChangeTile(
            'كلمة المرور',
            Icons.lock,
            passwordController,
            'كلمة المرور',
          ),
          const SizedBox(height: 16),
          ListTile(
            leading: Icon(Icons.security, color: AppTheme.primaryColor),
            title: Text(
              'تسجيل الدخول من جهاز جديد؟',
              style: GoogleFonts.cairo(),
            ),
            subtitle: Text(
              'سيتم إرسال إشعار عند دخول الحساب من جهاز جديد',
              style: GoogleFonts.cairo(fontSize: 13, color: Colors.grey[700]),
            ),
          ),
        ],
      ),
    );
  }
}
