import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PrivacyScreen extends StatefulWidget {
  const PrivacyScreen({super.key});

  @override
  State<PrivacyScreen> createState() => _PrivacyScreenState();
}

class _PrivacyScreenState extends State<PrivacyScreen> {
  bool readReceipts = true;
  bool showInSearch = false;
  bool showCityCountry = false;
  bool showTripType = false;
  bool showStayDuration = true;
  bool showBookedServices = false;

  void _confirmDeleteAccount() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف الحساب'),
        content: const Text(
          'هل أنت متأكد أنك تريد حذف حسابك نهائيًا؟ هذا الإجراء لا يمكن التراجع عنه.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('تم تنفيذ عملية حذف الحساب (تجريبياً).'),
                ),
              );
            },
            child: const Text(
              'تأكيد الحذف',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(
        title,
        style: GoogleFonts.cairo(fontSize: 15, fontWeight: FontWeight.bold),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'الخصوصية',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'تحكم بكيفية ظهور معلوماتك والتفاعل معها داخل التطبيق:',
            style: GoogleFonts.cairo(fontSize: 16),
          ),

          buildSectionTitle('الرسائل'),
          SwitchListTile(
            title: const Text('إظهار علامة القراءة'),
            subtitle: const Text('يعرف الطرف الآخر أنك قرأت رسالته'),
            value: readReceipts,
            onChanged: (val) => setState(() => readReceipts = val),
          ),
          ListTile(
            title: const Text('إدارة قائمة الحظر'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('سيتم توجيهك إلى صفحة الحظر قريبًا'),
                ),
              );
            },
          ),

          buildSectionTitle('الظهور والإعلانات'),
          SwitchListTile(
            title: const Text('تضمين ملفي في نتائج البحث'),
            value: showInSearch,
            onChanged: (val) => setState(() => showInSearch = val),
          ),
          SwitchListTile(
            title: const Text('إظهار المدينة والبلد'),
            value: showCityCountry,
            onChanged: (val) => setState(() => showCityCountry = val),
          ),
          SwitchListTile(
            title: const Text('إظهار نوع الرحلة'),
            value: showTripType,
            onChanged: (val) => setState(() => showTripType = val),
          ),
          SwitchListTile(
            title: const Text('إظهار مدة الإقامة'),
            value: showStayDuration,
            onChanged: (val) => setState(() => showStayDuration = val),
          ),
          SwitchListTile(
            title: const Text('إظهار الخدمات المحجوزة'),
            value: showBookedServices,
            onChanged: (val) => setState(() => showBookedServices = val),
          ),

          buildSectionTitle('حذف الحساب'),
          ElevatedButton(
            onPressed: _confirmDeleteAccount,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red.shade600,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            child: const Text('حذف حسابي نهائيًا'),
          ),
        ],
      ),
    );
  }
}
