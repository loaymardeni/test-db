import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';
import 'package:go_router/go_router.dart';

class RateStayScreen extends StatefulWidget {
  final String roomTitle;

  const RateStayScreen({super.key, required this.roomTitle});

  @override
  State<RateStayScreen> createState() => _RateStayScreenState();
}

class _RateStayScreenState extends State<RateStayScreen> {
  int _stayRating = 0;
  int _hostRating = 0;
  final TextEditingController _commentController = TextEditingController();

  void _submitRating() {
    if (_stayRating == 0 || _hostRating == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'يرجى تقييم الإقامة والمضيف قبل الإرسال',
            style: GoogleFonts.cairo(),
          ),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    // إرسال البيانات إلى السيرفر لاحقاً

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('شكراً على تقييمك!', style: GoogleFonts.cairo()),
        backgroundColor: AppTheme.primaryColor,
      ),
    );

    context.pop();
  }

  Widget buildStar(int index, int selectedValue, Function(int) onChanged) {
    return IconButton(
      splashRadius: 22,
      icon: Icon(
        index <= selectedValue ? Icons.star_rounded : Icons.star_border_rounded,
        color: Colors.amber,
        size: 32,
      ),
      onPressed: () => setState(() => onChanged(index)),
    );
  }

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'تقييم ${widget.roomTitle}',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'تقييم الإقامة:',
              style: GoogleFonts.cairo(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 7),
            Row(
              children: List.generate(
                5,
                (index) => buildStar(
                  index + 1,
                  _stayRating,
                  (val) => _stayRating = val,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'تقييم المضيف:',
              style: GoogleFonts.cairo(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 7),
            Row(
              children: List.generate(
                5,
                (index) => buildStar(
                  index + 1,
                  _hostRating,
                  (val) => _hostRating = val,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'تعليق (اختياري):',
              style: GoogleFonts.cairo(fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _commentController,
              maxLines: 3,
              style: GoogleFonts.cairo(),
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(13),
                ),
                hintText: 'اكتب رأيك...',
                hintStyle: GoogleFonts.cairo(color: AppTheme.greyColor),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _submitRating,
                icon: const Icon(Icons.send_rounded),
                label: Text(
                  'إرسال التقييم',
                  style: GoogleFonts.cairo(
                    fontWeight: FontWeight.bold,
                    fontSize: 17,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryColor,
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(52),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
