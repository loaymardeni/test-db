import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController cityController = TextEditingController();
  final TextEditingController minPriceController = TextEditingController();
  final TextEditingController maxPriceController = TextEditingController();
  final TextEditingController roomsController = TextEditingController();

  final List<Map<String, dynamic>> allProperties = [
    {
      'title': 'شقة فخمة',
      'city': 'دمشق',
      'price': 250,
      'rooms': 3,
      'imageUrl': 'https://via.placeholder.com/150',
    },
    {
      'title': 'بيت ريفي',
      'city': 'حمص',
      'price': 150,
      'rooms': 2,
      'imageUrl': 'https://via.placeholder.com/150',
    },
    {
      'title': 'استوديو صغير',
      'city': 'دمشق',
      'price': 100,
      'rooms': 1,
      'imageUrl': 'https://via.placeholder.com/150',
    },
  ];

  List<Map<String, dynamic>> searchResults = [];

  void performSearch() {
    FocusScope.of(context).unfocus();

    final cityInput = cityController.text.trim().toLowerCase();
    int minPrice = int.tryParse(minPriceController.text.trim()) ?? 0;
    int maxPrice = int.tryParse(maxPriceController.text.trim()) ?? 1000000;
    final rooms = int.tryParse(roomsController.text.trim());

    if (maxPrice < minPrice) {
      final temp = minPrice;
      minPrice = maxPrice;
      maxPrice = temp;
    }

    setState(() {
      searchResults = allProperties.where((property) {
        final city = (property['city'] as String).toLowerCase();
        final matchesCity = cityInput.isEmpty || city.contains(cityInput);
        final price = property['price'] as int;
        final matchesPrice = price >= minPrice && price <= maxPrice;
        final roomsCount = property['rooms'] as int;
        final matchesRooms = rooms == null || roomsCount == rooms;

        return matchesCity && matchesPrice && matchesRooms;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final inputDecoration = InputDecoration(
      filled: true,
      fillColor: Colors.white,
      labelStyle: GoogleFonts.cairo(fontSize: 16, color: Colors.grey[700]),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'بحث عن عقار',
          style: GoogleFonts.cairo(
            fontWeight: FontWeight.bold,
            color: AppTheme.primaryColor,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            TextField(
              controller: cityController,
              decoration: inputDecoration.copyWith(labelText: 'المدينة'),
              style: GoogleFonts.cairo(),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: minPriceController,
                    keyboardType: TextInputType.number,
                    decoration: inputDecoration.copyWith(
                      labelText: 'السعر الأدنى',
                    ),
                    style: GoogleFonts.cairo(),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: maxPriceController,
                    keyboardType: TextInputType.number,
                    decoration: inputDecoration.copyWith(
                      labelText: 'السعر الأعلى',
                    ),
                    style: GoogleFonts.cairo(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: roomsController,
              keyboardType: TextInputType.number,
              decoration: inputDecoration.copyWith(labelText: 'عدد الغرف'),
              style: GoogleFonts.cairo(),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: performSearch,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: GoogleFonts.cairo(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                icon: const Icon(Icons.search),
                label: const Text('ابحث'),
              ),
            ),
            const SizedBox(height: 22),
            Expanded(
              child: searchResults.isEmpty
                  ? Center(
                      child: Text(
                        'لا يوجد نتائج حتى الآن...',
                        style: GoogleFonts.cairo(
                          fontSize: 17,
                          color: AppTheme.greyColor,
                        ),
                      ),
                    )
                  : ListView.builder(
                      itemCount: searchResults.length,
                      itemBuilder: (context, index) {
                        final result = searchResults[index];
                        return Card(
                          elevation: 3,
                          margin: const EdgeInsets.symmetric(vertical: 8),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: ListTile(
                            leading: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(
                                result['imageUrl'],
                                width: 62,
                                height: 62,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) =>
                                    Container(
                                      width: 62,
                                      height: 62,
                                      color: Colors.grey.shade300,
                                      child: const Icon(
                                        Icons.home,
                                        color: Colors.grey,
                                      ),
                                    ),
                              ),
                            ),
                            title: Text(
                              result['title'],
                              style: GoogleFonts.cairo(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(
                              '${result['city']} • ${result['rooms']} غرف • ${result['price']} ل.س',
                              style: GoogleFonts.cairo(),
                            ),
                            onTap: () {
                              // مستقبلاً: الانتقال إلى شاشة التفاصيل
                            },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
