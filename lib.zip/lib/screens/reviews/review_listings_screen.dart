import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';
import '../../models/property.dart';
import 'package:go_router/go_router.dart';

class ReviewListingsScreen extends StatefulWidget {
  const ReviewListingsScreen({super.key});

  @override
  State<ReviewListingsScreen> createState() => _ReviewListingsScreenState();
}

class _ReviewListingsScreenState extends State<ReviewListingsScreen> {
  List<Property> listings = [
    Property(
      id: 'r1',
      title: 'شقة للايجار',
      location: 'حمص',
      price: 200,
      description: 'شقة ثلاث غرف وصالة - مناسب للعائلات',
      docsUrl: 'https://via.placeholder.com/150',
      imageUrls: ['https://via.placeholder.com/150'],
    ),
    Property(
      id: 'r2',
      title: 'فيلا مميزة',
      location: 'دمشق',
      price: 500,
      description: 'فيلا فاخرة مع مسبح وحديقة',
      docsUrl: 'https://via.placeholder.com/150',
      imageUrls: ['https://via.placeholder.com/150'],
    ),
  ];

  void _approve(Property listing) {
    setState(() {
      listings.removeWhere((l) => l.id == listing.id);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'تم اعتماد الإعلان: ${listing.title}',
          style: GoogleFonts.cairo(),
        ),
        backgroundColor: AppTheme.primaryColor,
      ),
    );
  }

  void _reject(Property listing) {
    setState(() {
      listings.removeWhere((l) => l.id == listing.id);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'تم رفض الإعلان: ${listing.title}',
          style: GoogleFonts.cairo(),
        ),
        backgroundColor: Colors.redAccent,
      ),
    );
  }

  void _showDetails(Property listing) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(
          'تفاصيل الإعلان',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (listing.imageUrls.isNotEmpty)
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    listing.imageUrls.first,
                    width: double.infinity,
                    height: 100,
                    fit: BoxFit.cover,
                  ),
                ),
              const SizedBox(height: 8),
              Text('العنوان: ${listing.title}', style: GoogleFonts.cairo()),
              Text('الموقع: ${listing.location}', style: GoogleFonts.cairo()),
              Text(
                'السعر: \$${listing.price.toStringAsFixed(0)}',
                style: GoogleFonts.cairo(),
              ),
              const SizedBox(height: 8),
              Text(
                'الوصف:',
                style: GoogleFonts.cairo(fontWeight: FontWeight.w600),
              ),
              Text(listing.description, style: GoogleFonts.cairo()),
              const SizedBox(height: 12),
              Text(
                'رابط الوثائق:',
                style: GoogleFonts.cairo(fontWeight: FontWeight.w600),
              ),
              Text(listing.docsUrl, style: GoogleFonts.cairo()),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => context.pop(),
            child: Text('إغلاق', style: GoogleFonts.cairo()),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'مراجعة الإعلانات',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 21,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: listings.isEmpty
          ? Center(
              child: Text(
                'لا توجد إعلانات للمراجعة',
                style: GoogleFonts.cairo(
                  fontSize: 17,
                  color: AppTheme.greyColor,
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: listings.length,
              itemBuilder: (context, index) {
                final listing = listings[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  elevation: 3,
                  color: Colors.white,
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(12),
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        listing.imageUrls.isNotEmpty
                            ? listing.imageUrls.first
                            : 'https://via.placeholder.com/60',
                        width: 60,
                        height: 60,
                        fit: BoxFit.cover,
                      ),
                    ),
                    title: Text(
                      listing.title,
                      style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      '${listing.location} • \$${listing.price.toStringAsFixed(0)}',
                      style: GoogleFonts.cairo(),
                    ),
                    onTap: () => _showDetails(listing),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.check, color: Colors.green),
                          tooltip: 'اعتماد',
                          onPressed: () => _approve(listing),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.red),
                          tooltip: 'رفض',
                          onPressed: () => _reject(listing),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
