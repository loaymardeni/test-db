import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class PropertySearchScreen extends StatefulWidget {
  const PropertySearchScreen({super.key});

  @override
  State<PropertySearchScreen> createState() => _PropertySearchScreenState();
}

class _PropertySearchScreenState extends State<PropertySearchScreen> {
  final TextEditingController _searchController = TextEditingController();

  String? selectedCity;
  String? selectedType;

  final List<String> cities = ['دمشق', 'حلب', 'اللاذقية', 'طرطوس'];
  final List<String> propertyTypes = ['غرفة', 'شقة', 'فيلا'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'ابحث عن عقار',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 21,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              style: GoogleFonts.cairo(),
              decoration: InputDecoration(
                hintText: 'ابحث عن مدينة أو اسم عقار...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                filled: true,
                fillColor: Colors.white,
                hintStyle: GoogleFonts.cairo(color: AppTheme.greyColor),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      labelText: 'المدينة',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      labelStyle: GoogleFonts.cairo(),
                    ),
                    value: selectedCity,
                    style: GoogleFonts.cairo(),
                    items: cities
                        .map(
                          (city) => DropdownMenuItem(
                            value: city,
                            child: Text(city, style: GoogleFonts.cairo()),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedCity = value;
                      });
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      labelText: 'نوع العقار',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      labelStyle: GoogleFonts.cairo(),
                    ),
                    value: selectedType,
                    style: GoogleFonts.cairo(),
                    items: propertyTypes
                        .map(
                          (type) => DropdownMenuItem(
                            value: type,
                            child: Text(type, style: GoogleFonts.cairo()),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedType = value;
                      });
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 22),
            Expanded(
              child: ListView.builder(
                itemCount: 5,
                itemBuilder: (context, index) {
                  return Card(
                    margin: const EdgeInsets.symmetric(
                      vertical: 7,
                      horizontal: 2,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                    elevation: 3,
                    color: Colors.white,
                    child: ListTile(
                      leading: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Container(
                          width: 70,
                          height: 70,
                          color: Colors.grey[200],
                          child: const Icon(
                            Icons.home,
                            size: 34,
                            color: Colors.teal,
                          ),
                        ),
                      ),
                      title: Text(
                        'عقار رقم ${index + 1}',
                        style: GoogleFonts.cairo(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: AppTheme.primaryColor,
                        ),
                      ),
                      subtitle: Text(
                        'دمشق - السعر: 200,000 ل.س / شهر',
                        style: GoogleFonts.cairo(
                          color: AppTheme.greyColor,
                          fontSize: 13,
                        ),
                      ),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 19),
                      onTap: () {
                        // لاحقاً: context.push('/property-details', extra: property);
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
