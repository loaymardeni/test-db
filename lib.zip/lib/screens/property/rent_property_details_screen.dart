import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_image_slideshow/flutter_image_slideshow.dart';

import 'package:harbooq/models/property.dart';
import 'package:harbooq/theme/app_theme.dart';

class RentPropertyDetailsScreen extends StatelessWidget {
  final Property property;

  const RentPropertyDetailsScreen({super.key, required this.property});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: Text(property.title, style: GoogleFonts.cairo()),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        centerTitle: true,
      ),
      bottomNavigationBar: _buildBottomBar(context),
      body: SafeArea(
        child: ListView(
          children: [
            _buildImageCarousel(property),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(property),
                  const SizedBox(height: 8),
                  _buildInfoRow(property),
                  const Divider(height: 30),
                  _buildComfortIcons(),
                  const Divider(height: 30),
                  _buildSectionTitle('الوصف'),
                  const SizedBox(height: 8),
                  Text(
                    property.description,
                    style: GoogleFonts.cairo(
                      fontSize: 15,
                      color: Colors.grey[700],
                    ),
                  ),
                  const Divider(height: 30),
                  _buildSectionTitle('سياسات الإلغاء'),
                  const SizedBox(height: 8),
                  Text(
                    'مرنة – استرداد كامل حتى 24 ساعة قبل الوصول.',
                    style: GoogleFonts.cairo(),
                  ),
                  const Divider(height: 30),
                  _buildSectionTitle('معلومات المضيف'),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const CircleAvatar(
                        radius: 24,
                        backgroundImage: AssetImage('assets/images/host.png'),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'محمود القادري',
                            style: GoogleFonts.cairo(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'يستضيف منذ 2022',
                            style: GoogleFonts.cairo(
                              fontSize: 13,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const Divider(height: 30),
                  _buildSectionTitle('الموقع'),
                  const SizedBox(height: 10),
                  Container(
                    height: 180,
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Center(
                      child: Text('📍 سيتم عرض الموقع على الخريطة لاحقًا'),
                    ),
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageCarousel(Property property) {
    return ImageSlideshow(
      width: double.infinity,
      height: 260,
      indicatorColor: AppTheme.primaryColor,
      autoPlayInterval: 0,
      isLoop: false,
      children: property.imageUrls.map((imgUrl) {
        return Image.network(
          imgUrl,
          fit: BoxFit.cover,
          width: double.infinity,
          errorBuilder: (context, error, stackTrace) => Container(
            color: Colors.grey[300],
            child: const Center(child: Icon(Icons.broken_image, size: 50)),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildHeader(Property property) {
    return Text(
      property.title,
      style: GoogleFonts.cairo(fontSize: 22, fontWeight: FontWeight.bold),
    );
  }

  Widget _buildInfoRow(Property property) {
    return Row(
      children: [
        const Icon(Icons.location_on, color: Colors.red),
        const SizedBox(width: 4),
        Text(
          property.location,
          style: GoogleFonts.cairo(fontSize: 14, color: Colors.grey[700]),
        ),
        const Spacer(),
        Text(
          '\$${property.price.toStringAsFixed(0)} / الليلة',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ],
    );
  }

  Widget _buildComfortIcons() {
    final List<Map<String, dynamic>> icons = [
      {'label': 'واي فاي', 'icon': Icons.wifi},
      {'label': 'مكيف', 'icon': Icons.ac_unit},
      {'label': 'مطبخ', 'icon': Icons.kitchen},
      {'label': 'غسالة', 'icon': Icons.local_laundry_service},
    ];

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: icons.map((item) {
        return Column(
          children: [
            Icon(
              item['icon'] as IconData,
              size: 28,
              color: AppTheme.primaryColor,
            ),
            const SizedBox(height: 6),
            Text(
              item['label'] as String,
              style: GoogleFonts.cairo(fontSize: 13),
            ),
          ],
        );
      }).toList(),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.bold),
    );
  }

  Widget _buildBottomBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey[300]!)),
      ),
      child: ElevatedButton.icon(
        onPressed: () {
          // تنفيذ التواصل أو الحجز
        },
        icon: const Icon(Icons.chat_bubble_outline),
        label: const Text('تواصل مع المضيف'),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppTheme.primaryColor,
          minimumSize: const Size.fromHeight(45),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}
