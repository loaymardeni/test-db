// lib/screens/property/add/sell_property_preview_screen.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';

class SellPropertyPreviewScreen extends StatefulWidget {
  final Map<String, dynamic> data;
  final bool isOwner;

  const SellPropertyPreviewScreen({
    super.key,
    required this.data,
    this.isOwner = true,
  });

  @override
  State<SellPropertyPreviewScreen> createState() =>
      _SellPropertyPreviewScreenState();
}

class _SellPropertyPreviewScreenState extends State<SellPropertyPreviewScreen> {
  late Map<String, dynamic> data;
  bool isPublished = false;
  bool isEditing = false;

  @override
  void initState() {
    super.initState();
    data = Map<String, dynamic>.from(widget.data);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          isPublished ? '✅ تم النشر' : 'مراجعة الإعلان',
          style: const TextStyle(color: Colors.black87),
        ),
        backgroundColor: Colors.white,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.black87),
        actions: widget.isOwner && !isPublished
            ? [
                IconButton(
                  icon: Icon(
                    isEditing ? Icons.save : Icons.edit,
                    color: Colors.black87,
                  ),
                  tooltip: isEditing ? 'حفظ التعديلات' : 'تعديل',
                  onPressed: () {
                    if (isEditing) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('✅ تم حفظ التعديلات')),
                      );
                    }
                    setState(() => isEditing = !isEditing);
                  },
                ),
              ]
            : null,
      ),
      backgroundColor: const Color(0xFFF8F8F8),
      body: isPublished ? _buildSuccessContent() : _buildPreviewContent(),
    );
  }

  Widget _buildPreviewContent() {
    final String type = data['type']?.toString() ?? 'غير محدد';
    final String description = data['description']?.toString() ?? 'لا يوجد وصف';
    final List<String> imagePaths = List<String>.from(data['images'] ?? []);
    final details = data['details'] as Map<String, dynamic>? ?? {};

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildMainImage(imagePaths),
          const SizedBox(height: 16),

          _buildSectionTitle('📍 نوع العقار'),
          _buildEditableRow('النوع', type, (val) => data['type'] = val),

          _buildSectionTitle('📐 التفاصيل'),
          if (details.isNotEmpty)
            ...details.entries.map(
              (e) => _buildEditableRow(
                e.key,
                e.value.toString(),
                (val) => data['details'][e.key] = val,
              ),
            )
          else
            _buildEditableRow('تفاصيل', 'لا توجد معلومات', (_) {}),

          _buildSectionTitle('📝 الوصف'),
          _buildEditableRow(
            'الوصف',
            description,
            (val) => data['description'] = val,
          ),

          _buildSectionTitle('🖼️ الصور'),
          _buildImagesPreview(imagePaths),

          const SizedBox(height: 24),
          if (widget.isOwner) ...[
            ElevatedButton.icon(
              onPressed: _submitAndPublish,
              icon: const Icon(Icons.publish),
              label: const Text('نشر العقار الآن'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green[700],
                minimumSize: const Size.fromHeight(45),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _stopPublishing,
              icon: const Icon(Icons.visibility_off),
              label: const Text('إيقاف النشر'),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(45),
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _deleteProperty,
              icon: const Icon(Icons.delete_outline),
              label: const Text('حذف العقار'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.red,
                minimumSize: const Size.fromHeight(45),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSuccessContent() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle, color: Colors.green, size: 80),
            const SizedBox(height: 20),
            const Text(
              'تم نشر إعلانك بنجاح!',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: () => context.go('/main'),
              icon: const Icon(Icons.home),
              label: const Text('العودة إلى الرئيسية'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMainImage(List<String> paths) {
    if (paths.isEmpty) {
      return Container(
        height: 200,
        decoration: BoxDecoration(
          color: Colors.grey[300],
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Center(child: Text('لا توجد صور')),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image.network(
        paths.first,
        height: 200,
        width: double.infinity,
        fit: BoxFit.cover,
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(
        title,
        style: GoogleFonts.cairo(
          fontWeight: FontWeight.bold,
          fontSize: 17,
          color: Colors.black87,
        ),
      ),
    );
  }

  Widget _buildEditableRow(
    String label,
    String value,
    Function(String) onChanged,
  ) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(label, style: const TextStyle(color: Colors.grey)),
      subtitle: isEditing
          ? TextField(
              controller: TextEditingController(text: value),
              onSubmitted: onChanged,
              decoration: const InputDecoration(border: OutlineInputBorder()),
            )
          : Text(value, style: GoogleFonts.cairo()),
    );
  }

  Widget _buildImagesPreview(List<String> paths) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: paths
          .map(
            (path) => ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                path,
                width: 100,
                height: 100,
                fit: BoxFit.cover,
              ),
            ),
          )
          .toList(),
    );
  }

  void _submitAndPublish() {
    setState(() => isPublished = true);
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('✅ تم نشر العقار بنجاح')));
  }

  void _stopPublishing() {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('🚫 تم إيقاف نشر العقار')));
  }

  void _deleteProperty() {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('❌ تم حذف العقار')));
  }
}
