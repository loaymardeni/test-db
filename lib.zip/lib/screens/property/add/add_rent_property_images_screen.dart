import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:go_router/go_router.dart';

class AddRentPropertyImagesScreen extends StatefulWidget {
  final Map<String, dynamic> propertyData;
  const AddRentPropertyImagesScreen({super.key, required this.propertyData});

  @override
  State<AddRentPropertyImagesScreen> createState() =>
      _AddRentPropertyImagesScreenState();
}

class _AddRentPropertyImagesScreenState
    extends State<AddRentPropertyImagesScreen> {
  final List<File> _images = [];

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _images.add(File(picked.path)));
    }
  }

  void _goToPreview() {
    final updatedData = Map<String, dynamic>.from(widget.propertyData);
    updatedData['images'] = _images;
    context.push('/add/rent/preview', extra: updatedData);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تحميل الصور')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ElevatedButton.icon(
              onPressed: _pickImage,
              icon: const Icon(Icons.add_a_photo),
              label: const Text('إضافة صورة'),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: GridView.builder(
                itemCount: _images.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                itemBuilder: (_, index) => Stack(
                  children: [
                    Image.file(
                      _images[index],
                      fit: BoxFit.cover,
                      width: double.infinity,
                    ),
                    Positioned(
                      top: 0,
                      right: 0,
                      child: IconButton(
                        icon: const Icon(Icons.cancel, color: Colors.red),
                        onPressed: () =>
                            setState(() => _images.removeAt(index)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _images.isNotEmpty ? _goToPreview : null,
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              child: const Text('التالي'),
            ),
          ],
        ),
      ),
    );
  }
}
