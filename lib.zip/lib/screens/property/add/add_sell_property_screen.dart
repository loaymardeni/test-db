import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';

class AddSellPropertyScreen extends StatefulWidget {
  const AddSellPropertyScreen({super.key});

  @override
  State<AddSellPropertyScreen> createState() => _AddSellPropertyScreenState();
}

class _AddSellPropertyScreenState extends State<AddSellPropertyScreen> {
  String? selectedType;
  final Map<String, List<String>> fieldsByType = {
    'شقة': [
      'عدد الغرف',
      'عدد الحمامات',
      'الطابق',
      'هل يوجد مصعد؟',
      'نوع التدفئة',
      'المساحة (م²)',
      'مفروشة؟',
      'الإطلالة',
      'السعر',
    ],
    'بيت مستقل': [
      'عدد الطوابق',
      'عدد الغرف',
      'عدد الحمامات',
      'مساحة الأرض (م²)',
      'مساحة البناء (م²)',
      'يوجد كراج؟',
      'يوجد حديقة؟',
      'مفروش؟',
      'السعر',
    ],
    'فيلا': [
      'عدد الطوابق',
      'عدد الغرف',
      'عدد الحمامات',
      'مساحة الأرض (م²)',
      'مساحة البناء (م²)',
      'يوجد كراج؟',
      'يوجد حديقة؟',
      'مسبح؟',
      'نوع التشطيب',
      'مفروشة؟',
      'السعر',
    ],
    'مزرعة': [
      'مساحة الأرض (م²)',
      'يوجد ماء؟',
      'يوجد كهرباء؟',
      'نوع المزروعات',
      'هل الأرض مسوّرة؟',
      'السعر',
    ],
    'أرض (بناء / زراعية)': [
      'نوع الأرض',
      'تنظيم العقار',
      'المساحة (م²)',
      'نوع الملكية',
      'السعر',
    ],
    'محل تجاري': [
      'المساحة (م²)',
      'الطابق',
      'واجهة العرض',
      'نوع النشاط التجاري',
      'السعر',
    ],
    'مكتب': ['المساحة (م²)', 'الطابق', 'عدد الصالات', 'مفروش؟', 'السعر'],
    'بناية كاملة': ['عدد الطوابق', 'عدد الشقق', 'مساحة الأرض (م²)', 'السعر'],
    'استوديو': ['المساحة (م²)', 'مفروش؟', 'السعر'],
    'حصة عقارية': [
      'نوع الملكية',
      'النسبة (مثلاً 1/2 أو 1/4)',
      'نوع العقار المشترك',
      'السعر',
    ],
  };

  final Map<String, TextEditingController> fieldControllers = {};
  final TextEditingController notesController = TextEditingController();

  @override
  void dispose() {
    for (final controller in fieldControllers.values) {
      controller.dispose();
    }
    notesController.dispose();
    super.dispose();
  }

  List<Widget> buildFieldsForType(String type) {
    final fields = fieldsByType[type] ?? [];
    return fields.map((field) {
      fieldControllers.putIfAbsent(field, () => TextEditingController());
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: TextFormField(
          controller: fieldControllers[field],
          decoration: InputDecoration(
            labelText: field,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ),
      );
    }).toList();
  }

  void goToImagesStep() {
    context.push('/add/sell/images');
  }

  @override
  Widget build(BuildContext context) {
    final List<String> propertyTypes = fieldsByType.keys.toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('إضافة عقار للبيع', style: GoogleFonts.cairo()),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              decoration: InputDecoration(
                labelText: 'نوع العقار',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              value: selectedType,
              items: propertyTypes.map((type) {
                return DropdownMenuItem(
                  value: type,
                  child: Text(type, style: GoogleFonts.cairo()),
                );
              }).toList(),
              onChanged: (value) {
                setState(() => selectedType = value);
              },
            ),
            const SizedBox(height: 30),
            if (selectedType != null) ...[
              ...buildFieldsForType(selectedType!),
              const SizedBox(height: 20),
              TextFormField(
                controller: notesController,
                maxLines: 5,
                decoration: InputDecoration(
                  labelText: 'ملاحظات إضافية / وصف العقار',
                  alignLabelWithHint: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: goToImagesStep,
                icon: const Icon(Icons.arrow_forward),
                label: Text('التالي', style: GoogleFonts.cairo()),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
