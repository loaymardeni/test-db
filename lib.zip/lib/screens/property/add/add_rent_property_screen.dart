import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AddRentPropertyScreen extends StatefulWidget {
  const AddRentPropertyScreen({super.key});

  @override
  State<AddRentPropertyScreen> createState() => _AddRentPropertyScreenState();
}

class _AddRentPropertyScreenState extends State<AddRentPropertyScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  final TextEditingController _areaController = TextEditingController();
  final TextEditingController _cancellationController = TextEditingController();
  final TextEditingController _rulesController = TextEditingController();
  final TextEditingController _safetyController = TextEditingController();

  String? _selectedRentType;
  int _guests = 1;
  int _rooms = 1;
  int _beds = 1;
  double _bathrooms = 1.0;

  final List<String> _amenitiesOptions = [
    'واي فاي',
    'تلفزيون',
    'مطبخ',
    'تدفئة',
    'مكيف',
    'غسالة',
    'مصعد',
    'موقف سيارات',
    'شرفة',
    'إطلالة على البحر',
  ];
  final Set<String> _selectedAmenities = {};

  void _submit() {
    if (!_formKey.currentState!.validate()) return;

    final Map<String, dynamic> data = {
      'title': _titleController.text,
      'description': _descriptionController.text,
      'price': _priceController.text,
      'city': _cityController.text,
      'area': _areaController.text,
      'rentType': _selectedRentType,
      'guests': _guests,
      'rooms': _rooms,
      'beds': _beds,
      'bathrooms': _bathrooms,
      'amenities': _selectedAmenities.toList(),
      'cancellationPolicy': _cancellationController.text,
      'houseRules': _rulesController.text,
      'safetyDetails': _safetyController.text,
    };

    // ✅ هذا هو السطر المعدل
    context.push('/add/rent/images', extra: data);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة إعلان إيجار')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'عنوان العقار'),
              validator: (v) =>
                  v == null || v.isEmpty ? 'يرجى إدخال العنوان' : null,
            ),
            TextFormField(
              controller: _descriptionController,
              decoration: const InputDecoration(labelText: 'الوصف الكامل'),
              maxLines: 4,
            ),
            TextFormField(
              controller: _priceController,
              decoration: const InputDecoration(labelText: 'السعر'),
              keyboardType: TextInputType.number,
            ),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: 'نوع الإيجار'),
              value: _selectedRentType,
              items: ['يومي', 'أسبوعي', 'شهري']
                  .map(
                    (type) => DropdownMenuItem(value: type, child: Text(type)),
                  )
                  .toList(),
              onChanged: (val) => setState(() => _selectedRentType = val),
            ),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _cityController,
                    decoration: const InputDecoration(labelText: 'المدينة'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _areaController,
                    decoration: const InputDecoration(labelText: 'المنطقة'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildCounter(
                  'الضيوف',
                  _guests,
                  (v) => setState(() => _guests = v),
                ),
                _buildCounter(
                  'الغرف',
                  _rooms,
                  (v) => setState(() => _rooms = v),
                ),
                _buildCounter(
                  'الأسرة',
                  _beds,
                  (v) => setState(() => _beds = v),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Text('عدد الحمامات: '),
                Expanded(
                  child: Slider(
                    value: _bathrooms,
                    min: 1,
                    max: 5,
                    divisions: 8,
                    label: _bathrooms.toStringAsFixed(1),
                    onChanged: (val) => setState(() => _bathrooms = val),
                  ),
                ),
              ],
            ),
            const Divider(height: 32),
            const Text(
              'وسائل الراحة:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Wrap(
              spacing: 8,
              children: _amenitiesOptions.map((a) {
                return FilterChip(
                  label: Text(a),
                  selected: _selectedAmenities.contains(a),
                  onSelected: (selected) {
                    setState(() {
                      if (selected) {
                        _selectedAmenities.add(a);
                      } else {
                        _selectedAmenities.remove(a);
                      }
                    });
                  },
                );
              }).toList(),
            ),
            const Divider(height: 32),
            TextFormField(
              controller: _cancellationController,
              decoration: const InputDecoration(labelText: 'سياسة الإلغاء'),
              maxLines: 2,
            ),
            TextFormField(
              controller: _rulesController,
              decoration: const InputDecoration(labelText: 'قوانين العقار'),
              maxLines: 2,
            ),
            TextFormField(
              controller: _safetyController,
              decoration: const InputDecoration(labelText: 'تفاصيل السلامة'),
              maxLines: 2,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _submit,
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              child: const Text('التالي'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCounter(String label, int value, Function(int) onChanged) {
    return Column(
      children: [
        Text(label),
        Row(
          children: [
            IconButton(
              onPressed: value > 0 ? () => onChanged(value - 1) : null,
              icon: const Icon(Icons.remove),
            ),
            Text('$value'),
            IconButton(
              onPressed: () => onChanged(value + 1),
              icon: const Icon(Icons.add),
            ),
          ],
        ),
      ],
    );
  }
}
