import 'dart:io';

import 'package:flutter/material.dart';

class RentPropertyPreviewScreen extends StatelessWidget {
  final Map<String, dynamic> data;
  const RentPropertyPreviewScreen({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final List<File> images = List<File>.from(data['images'] ?? []);

    return Scaffold(
      appBar: AppBar(title: const Text('مراجعة الإعلان')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            data['title'] ?? '',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          Text(data['description'] ?? ''),
          const SizedBox(height: 12),
          Text('السعر: ${data['price']}'),
          Text('نوع الإيجار: ${data['rentType']}'),
          Text('المدينة: ${data['city']}'),
          Text('المنطقة: ${data['area']}'),
          Text('الضيوف: ${data['guests']}'),
          Text('الغرف: ${data['rooms']}'),
          Text('الأسرة: ${data['beds']}'),
          Text('الحمامات: ${data['bathrooms']}'),
          const Divider(height: 24),
          const Text(
            'وسائل الراحة:',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Wrap(
            spacing: 8,
            children: List<Widget>.from(
              (data['amenities'] ?? []).map((a) => Chip(label: Text(a))),
            ),
          ),
          const Divider(height: 24),
          Text('سياسة الإلغاء: ${data['cancellationPolicy']}'),
          Text('قوانين العقار: ${data['houseRules']}'),
          Text('تفاصيل السلامة: ${data['safetyDetails']}'),
          const Divider(height: 24),
          const Text('الصور:', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: images.length,
              itemBuilder: (_, i) => Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Image.file(images[i], width: 200, fit: BoxFit.cover),
              ),
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton(onPressed: () {}, child: const Text('نشر العقار')),
        ],
      ),
    );
  }
}
