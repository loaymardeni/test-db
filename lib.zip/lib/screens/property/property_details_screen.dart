import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/models/property.dart';
import 'package:harbooq/theme/app_theme.dart';

class PropertyDetailsScreen extends StatefulWidget {
  final Property property;
  final bool isOwner;

  const PropertyDetailsScreen({
    super.key,
    required this.property,
    this.isOwner = false,
  });

  @override
  State<PropertyDetailsScreen> createState() => _PropertyDetailsScreenState();
}

class _PropertyDetailsScreenState extends State<PropertyDetailsScreen> {
  bool _isEditing = false;
  late TextEditingController _titleController;
  late TextEditingController _locationController;
  late TextEditingController _priceController;
  late TextEditingController _descriptionController;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.property.title);
    _locationController = TextEditingController(text: widget.property.location);
    _priceController = TextEditingController(
      text: widget.property.price.toStringAsFixed(0),
    );
    _descriptionController = TextEditingController(
      text: widget.property.description,
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _locationController.dispose();
    _priceController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  void _toggleEdit() {
    setState(() {
      _isEditing = !_isEditing;
    });
  }

  void _saveChanges() {
    setState(() {
      _isEditing = false;
      // يمكن تخزين القيم الجديدة لاحقاً أو إرسالها للسيرفر
    });
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('تم حفظ التعديلات')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.property.title,
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 21,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
        actions: widget.isOwner
            ? [
                IconButton(
                  icon: Icon(_isEditing ? Icons.close : Icons.edit),
                  onPressed: _toggleEdit,
                  tooltip: _isEditing ? 'إلغاء التعديل' : 'تعديل',
                ),
              ]
            : null,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildMainImage(),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildEditableField(
                    label: 'عنوان العقار',
                    controller: _titleController,
                  ),
                  const SizedBox(height: 8),
                  _buildEditableField(
                    label: 'الموقع',
                    controller: _locationController,
                  ),
                  const SizedBox(height: 8),
                  _buildEditableField(
                    label: 'السعر (\$)',
                    controller: _priceController,
                  ),
                  const SizedBox(height: 12),
                  _buildPriceAnalysis(),
                  const SizedBox(height: 12),
                  _buildAccordionSections(),
                  const SizedBox(height: 20),
                  _buildMapPlaceholder(),
                  const SizedBox(height: 24),
                  if (widget.isOwner && !_isEditing) _buildOwnerActions(),
                  if (!widget.isOwner) _buildContactSection(),
                  const SizedBox(height: 16),
                  _buildSimilarProperties(),
                  const SizedBox(height: 24),
                  if (_isEditing)
                    ElevatedButton.icon(
                      onPressed: _saveChanges,
                      icon: const Icon(Icons.save),
                      label: const Text('حفظ التعديلات'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        minimumSize: const Size.fromHeight(45),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEditableField({
    required String label,
    required TextEditingController controller,
  }) {
    return TextField(
      controller: controller,
      readOnly: !_isEditing,
      decoration: InputDecoration(
        labelText: label,
        suffixIcon: _isEditing ? const Icon(Icons.edit) : null,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        filled: true,
        fillColor: _isEditing ? Colors.white : Colors.grey[200],
      ),
    );
  }

  Widget _buildMainImage() {
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        bottomLeft: Radius.circular(16),
        bottomRight: Radius.circular(16),
      ),
      child: Image.network(
        widget.property.docsUrl,
        height: 230,
        width: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => Container(
          height: 230,
          color: Colors.grey[200],
          child: const Icon(Icons.image_not_supported, size: 60),
        ),
      ),
    );
  }

  Widget _buildPriceAnalysis() {
    return Row(
      children: [
        const Icon(Icons.trending_up, color: Colors.green),
        const SizedBox(width: 6),
        Text(
          'سعر ممتاز مقارنة بالسوق',
          style: GoogleFonts.cairo(
            color: Colors.green[700],
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildAccordionSections() {
    return Column(
      children: [
        ExpansionTile(
          title: Text('الوصف', style: GoogleFonts.cairo()),
          children: [
            _isEditing
                ? TextField(
                    controller: _descriptionController,
                    maxLines: null,
                    decoration: InputDecoration(
                      hintText: 'أدخل وصف العقار',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  )
                : Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      widget.property.description,
                      style: GoogleFonts.cairo(color: Colors.grey[700]),
                    ),
                  ),
          ],
        ),
        ExpansionTile(
          title: Text('مواصفات عامة', style: GoogleFonts.cairo()),
          children: const [
            ListTile(title: Text('البناء: حجر')),
            ListTile(title: Text('عدد الطوابق: 2')),
          ],
        ),
        ExpansionTile(
          title: Text('تفاصيل داخلية', style: GoogleFonts.cairo()),
          children: const [
            ListTile(title: Text('3 غرف نوم')),
            ListTile(title: Text('1 حمام')),
          ],
        ),
        ExpansionTile(
          title: Text('التمويل والطاقة', style: GoogleFonts.cairo()),
          children: const [
            ListTile(title: Text('قابل للتقسيط')),
            ListTile(title: Text('شهادة الطاقة: B')),
          ],
        ),
      ],
    );
  }

  Widget _buildMapPlaceholder() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('الموقع على الخريطة', style: GoogleFonts.cairo(fontSize: 16)),
        const SizedBox(height: 10),
        Container(
          height: 180,
          decoration: BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Center(child: Text('📍 خريطة سيتم تفعيلها لاحقًا')),
        ),
      ],
    );
  }

  Widget _buildContactSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('تواصل مع المعلن', style: GoogleFonts.cairo(fontSize: 17)),
        const SizedBox(height: 10),
        TextField(decoration: _inputDecoration('الاسم الكامل')),
        const SizedBox(height: 8),
        TextField(decoration: _inputDecoration('رقم الهاتف')),
        const SizedBox(height: 8),
        TextField(decoration: _inputDecoration('رسالتك'), maxLines: 3),
        const SizedBox(height: 12),
        ElevatedButton(
          onPressed: () {},
          style: ElevatedButton.styleFrom(
            backgroundColor: AppTheme.primaryColor,
            minimumSize: const Size.fromHeight(45),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: const Text('إرسال'),
        ),
      ],
    );
  }

  Widget _buildOwnerActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ElevatedButton.icon(
          onPressed: _toggleEdit,
          icon: const Icon(Icons.edit),
          label: const Text('تعديل العقار'),
        ),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          onPressed: () {},
          icon: const Icon(Icons.visibility_off),
          label: const Text('إيقاف النشر'),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
        ),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          onPressed: () {},
          icon: const Icon(Icons.delete),
          label: const Text('حذف العقار'),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
        ),
      ],
    );
  }

  Widget _buildSimilarProperties() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('عقارات مشابهة', style: GoogleFonts.cairo(fontSize: 17)),
        const SizedBox(height: 10),
        SizedBox(
          height: 130,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: List.generate(
              2,
              (index) => Container(
                width: 180,
                margin: const EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.grey[200],
                ),
                child: const Center(child: Text('عقار مشابه')),
              ),
            ),
          ),
        ),
      ],
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      filled: true,
      fillColor: Colors.white,
    );
  }
}
