import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class BookingRequest {
  final String id;
  final String tenantName;
  final String propertyImageUrl;
  final DateTime fromDate;
  final DateTime toDate;
  String status;

  BookingRequest({
    required this.id,
    required this.tenantName,
    required this.propertyImageUrl,
    required this.fromDate,
    required this.toDate,
    this.status = 'pending',
  });
}

class BookingRequestsScreen extends StatefulWidget {
  const BookingRequestsScreen({super.key});

  @override
  State<BookingRequestsScreen> createState() => _BookingRequestsScreenState();
}

class _BookingRequestsScreenState extends State<BookingRequestsScreen> {
  List<BookingRequest> requests = [
    BookingRequest(
      id: 'r1',
      tenantName: 'محمد علي',
      propertyImageUrl: 'https://picsum.photos/200/150?random=1',
      fromDate: DateTime.now().add(const Duration(days: 3)),
      toDate: DateTime.now().add(const Duration(days: 7)),
    ),
    BookingRequest(
      id: 'r2',
      tenantName: 'ليلى حسين',
      propertyImageUrl: 'https://picsum.photos/200/150?random=2',
      fromDate: DateTime.now().add(const Duration(days: 10)),
      toDate: DateTime.now().add(const Duration(days: 15)),
    ),
  ];

  void acceptRequest(String id) {
    setState(() {
      final index = requests.indexWhere((r) => r.id == id);
      if (index != -1) requests[index].status = 'accepted';
    });
  }

  void rejectRequest(String id) {
    setState(() {
      final index = requests.indexWhere((r) => r.id == id);
      if (index != -1) requests[index].status = 'rejected';
    });
  }

  String formatDate(DateTime d) {
    return "${d.day}/${d.month}/${d.year}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'طلبات الحجز',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: requests.isEmpty
          ? Center(
              child: Text(
                'لا توجد طلبات حجز حالياً',
                style: GoogleFonts.cairo(
                  fontSize: 18,
                  color: AppTheme.greyColor.withAlpha(178),
                ),
              ),
            )
          : ListView.builder(
              itemCount: requests.length,
              padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
              itemBuilder: (context, index) {
                final req = requests[index];
                return Card(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 8,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  elevation: 4,
                  color: Colors.white,
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(14),
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        req.propertyImageUrl,
                        width: 75,
                        height: 55,
                        fit: BoxFit.cover,
                      ),
                    ),
                    title: Text(
                      req.tenantName,
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                        color: AppTheme.primaryColor,
                      ),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 6),
                        Text(
                          'من: ${formatDate(req.fromDate)}  إلى: ${formatDate(req.toDate)}',
                          style: GoogleFonts.cairo(fontSize: 15),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'الحالة: ${req.status == 'pending'
                              ? 'معلق'
                              : req.status == 'accepted'
                              ? 'مقبول'
                              : 'مرفوض'}',
                          style: GoogleFonts.cairo(
                            fontWeight: FontWeight.w700,
                            color: req.status == 'accepted'
                                ? Colors.green
                                : req.status == 'rejected'
                                ? Colors.red
                                : Colors.orange,
                          ),
                        ),
                      ],
                    ),
                    trailing: req.status == 'pending'
                        ? Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: Icon(
                                  Icons.check_circle,
                                  color: Colors.green.shade700,
                                  size: 28,
                                ),
                                onPressed: () => acceptRequest(req.id),
                                tooltip: 'قبول الطلب',
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.cancel,
                                  color: Colors.red.shade600,
                                  size: 28,
                                ),
                                onPressed: () => rejectRequest(req.id),
                                tooltip: 'رفض الطلب',
                              ),
                            ],
                          )
                        : null,
                    onTap: () {
                      // لاحقاً: فتح تفاصيل الحجز أو شات
                    },
                  ),
                );
              },
            ),
    );
  }
}
