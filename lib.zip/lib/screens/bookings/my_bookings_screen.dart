import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class MyBookingsScreen extends StatefulWidget {
  const MyBookingsScreen({super.key});

  @override
  State<MyBookingsScreen> createState() => _MyBookingsScreenState();
}

class Booking {
  final String propertyTitle;
  final int nights;
  final DateTime startDate;
  final String status;

  Booking({
    required this.propertyTitle,
    required this.nights,
    required this.startDate,
    required this.status,
  });
}

class _MyBookingsScreenState extends State<MyBookingsScreen> {
  final List<Booking> bookings = [
    Booking(
      propertyTitle: 'شقة في دمشق',
      nights: 5,
      startDate: DateTime.now().add(const Duration(days: 2)),
      status: 'مؤكد',
    ),
    Booking(
      propertyTitle: 'غرفة في حلب',
      nights: 3,
      startDate: DateTime.now().subtract(const Duration(days: 10)),
      status: 'مكتمل',
    ),
    Booking(
      propertyTitle: 'بيت في اللاذقية',
      nights: 7,
      startDate: DateTime.now().add(const Duration(days: 15)),
      status: 'معلق',
    ),
  ];

  void _cancelBooking(int index) {
    setState(() {
      bookings[index] = Booking(
        propertyTitle: bookings[index].propertyTitle,
        nights: bookings[index].nights,
        startDate: bookings[index].startDate,
        status: 'ملغي',
      );
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'تم إلغاء الحجز لـ ${bookings[index].propertyTitle}',
          style: GoogleFonts.cairo(),
        ),
        backgroundColor: Colors.redAccent,
      ),
    );
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'مؤكد':
        return Colors.green;
      case 'معلق':
        return Colors.orange;
      case 'ملغي':
        return Colors.redAccent;
      case 'مكتمل':
        return AppTheme.primaryColor;
      default:
        return AppTheme.greyColor;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'حجوزاتي',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 21,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: bookings.isEmpty
          ? Center(
              child: Text(
                'لا توجد حجوزات حالياً',
                style: GoogleFonts.cairo(
                  fontSize: 18,
                  color: AppTheme.greyColor,
                ),
              ),
            )
          : ListView.builder(
              itemCount: bookings.length,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              itemBuilder: (context, index) {
                final booking = bookings[index];
                final canCancel =
                    booking.status == 'مؤكد' || booking.status == 'معلق';

                return Card(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 8,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 4,
                  color: Colors.white,
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(
                      vertical: 13,
                      horizontal: 16,
                    ),
                    title: Text(
                      booking.propertyTitle,
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: AppTheme.primaryColor,
                      ),
                    ),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'عدد الليالي: ${booking.nights}',
                            style: GoogleFonts.cairo(
                              fontSize: 14,
                              color: AppTheme.greyColor,
                            ),
                          ),
                          Text(
                            'تاريخ البدء: ${booking.startDate.toLocal().toString().split(' ')[0]}',
                            style: GoogleFonts.cairo(
                              fontSize: 14,
                              color: AppTheme.greyColor,
                            ),
                          ),
                          Row(
                            children: [
                              Text(
                                'الحالة: ',
                                style: GoogleFonts.cairo(fontSize: 14),
                              ),
                              Text(
                                booking.status,
                                style: GoogleFonts.cairo(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: _statusColor(booking.status),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    isThreeLine: true,
                    trailing: canCancel
                        ? IconButton(
                            icon: const Icon(
                              Icons.cancel,
                              color: Colors.redAccent,
                              size: 26,
                            ),
                            tooltip: 'إلغاء الحجز',
                            onPressed: () => _cancelBooking(index),
                          )
                        : null,
                    onTap: () {
                      // لاحقاً: إضافة تفاصيل الحجز عند الضغط
                    },
                  ),
                );
              },
            ),
    );
  }
}
