import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class BookingScreen extends StatefulWidget {
  final String roomTitle;

  const BookingScreen({super.key, required this.roomTitle});

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  final TextEditingController _nameController = TextEditingController();
  int _nights = 1;
  int _numGuests = 1;

  static const List<String> _extraServices = [
    'تنظيف يومي',
    'إفطار',
    'مواصلات من المطار',
  ];
  final List<String> _selectedServices = [];

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _submitBooking() {
    final name = _nameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'الرجاء إدخال اسمك قبل تأكيد الحجز',
            style: GoogleFonts.cairo(),
          ),
        ),
      );
      return;
    }

    final servicesText = _selectedServices.isEmpty
        ? 'بدون خدمات إضافية'
        : 'خدمات إضافية: ${_selectedServices.join(', ')}';

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(
          'تم الحجز!',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        content: Text(
          'شكراً $name، تم حجز "${widget.roomTitle}" لمدة $_nights ليلة.\n'
          'عدد الأشخاص: $_numGuests\n$servicesText',
          style: GoogleFonts.cairo(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst),
            child: Text(
              'رجوع للرئيسية',
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'حجز ${widget.roomTitle}',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: ListView(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'اسمك',
                labelStyle: GoogleFonts.cairo(),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                filled: true,
                fillColor: Colors.white,
              ),
              style: GoogleFonts.cairo(),
              keyboardType: TextInputType.name,
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Text(
                  'عدد الليالي:',
                  style: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                ),
                const SizedBox(width: 10),
                IconButton(
                  icon: const Icon(Icons.remove_circle_outline),
                  color: AppTheme.primaryColor,
                  onPressed: () {
                    if (_nights > 1) setState(() => _nights--);
                  },
                ),
                Text(
                  '$_nights',
                  style: GoogleFonts.cairo(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.add_circle_outline),
                  color: AppTheme.primaryColor,
                  onPressed: () => setState(() => _nights++),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Text(
                  'عدد الأشخاص:',
                  style: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                ),
                const SizedBox(width: 18),
                DropdownButton<int>(
                  value: _numGuests,
                  dropdownColor: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  style: GoogleFonts.cairo(
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                  items: List.generate(
                    10,
                    (i) => DropdownMenuItem(
                      value: i + 1,
                      child: Text('${i + 1}', style: GoogleFonts.cairo()),
                    ),
                  ),
                  onChanged: (val) {
                    if (val != null) {
                      setState(() => _numGuests = val);
                    }
                  },
                ),
              ],
            ),
            const SizedBox(height: 24),
            Text(
              'خدمات إضافية (اختياري):',
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryColor,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 8),
            ..._extraServices.map((service) {
              return CheckboxListTile(
                title: Text(service, style: GoogleFonts.cairo()),
                value: _selectedServices.contains(service),
                activeColor: AppTheme.primaryColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                onChanged: (val) {
                  setState(() {
                    if (val == true) {
                      _selectedServices.add(service);
                    } else {
                      _selectedServices.remove(service);
                    }
                  });
                },
              );
            }),
            const SizedBox(height: 32),
            Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryColor,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 60,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  textStyle: GoogleFonts.cairo(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onPressed: _submitBooking,
                child: const Text('تأكيد الحجز'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
