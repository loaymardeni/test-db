import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class Booking {
  final String id;
  final String title;
  final String imageUrl;
  final DateTime startDate;
  final int nights;
  String status;

  Booking({
    required this.id,
    required this.title,
    required this.imageUrl,
    required this.startDate,
    required this.nights,
    this.status = 'معلق',
  });
}

class BookingsListScreen extends StatefulWidget {
  const BookingsListScreen({super.key});

  @override
  State<BookingsListScreen> createState() => _BookingsListScreenState();
}

class _BookingsListScreenState extends State<BookingsListScreen> {
  int selectedTab = 0;

  final List<Booking> bookings = [
    Booking(
      id: 'b1',
      title: 'غرفة عائلية في دمشق',
      imageUrl: 'https://via.placeholder.com/180',
      startDate: DateTime.now().add(const Duration(days: 1)),
      nights: 4,
      status: 'مؤكد',
    ),
    Booking(
      id: 'b2',
      title: 'شقة فاخرة في حلب',
      imageUrl: 'https://via.placeholder.com/180',
      startDate: DateTime.now().add(const Duration(days: 5)),
      nights: 3,
      status: 'معلق',
    ),
    Booking(
      id: 'b3',
      title: 'غرفة في طرطوس',
      imageUrl: 'https://via.placeholder.com/180',
      startDate: DateTime.now().subtract(const Duration(days: 10)),
      nights: 2,
      status: 'مكتمل',
    ),
  ];

  List<Booking> get activeBookings =>
      bookings.where((b) => b.status == 'مؤكد' || b.status == 'معلق').toList();

  List<Booking> get completedBookings =>
      bookings.where((b) => b.status == 'مكتمل' || b.status == 'ملغي').toList();

  void _cancelBooking(String id) {
    setState(() {
      final idx = bookings.indexWhere((b) => b.id == id);
      if (idx != -1) bookings[idx].status = 'ملغي';
    });

    final cancelled = bookings.firstWhere((b) => b.id == id);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'تم إلغاء الحجز لـ ${cancelled.title}',
          style: GoogleFonts.cairo(),
        ),
        backgroundColor: Colors.redAccent,
      ),
    );
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'مؤكد':
        return Colors.green;
      case 'معلق':
        return Colors.orange;
      case 'ملغي':
        return Colors.redAccent;
      case 'مكتمل':
        return AppTheme.primaryColor;
      default:
        return AppTheme.greyColor;
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = selectedTab == 0 ? activeBookings : completedBookings;

    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: Text(
          'حجوزاتي',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [_buildTab('النشطة', 0), _buildTab('المكتملة', 1)],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: items.isEmpty
                  ? Center(
                      child: Text(
                        selectedTab == 0
                            ? 'لا توجد حجوزات نشطة'
                            : 'لا توجد حجوزات مكتملة',
                        style: GoogleFonts.cairo(
                          fontSize: 18,
                          color: AppTheme.greyColor,
                        ),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 6,
                      ),
                      itemCount: items.length,
                      itemBuilder: (context, index) {
                        final b = items[index];
                        final canCancel =
                            b.status == 'مؤكد' || b.status == 'معلق';
                        return Card(
                          margin: const EdgeInsets.only(bottom: 16),
                          elevation: 3,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(
                              vertical: 12,
                              horizontal: 16,
                            ),
                            leading: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.network(
                                b.imageUrl,
                                width: 65,
                                height: 65,
                                fit: BoxFit.cover,
                              ),
                            ),
                            title: Text(
                              b.title,
                              style: GoogleFonts.cairo(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: AppTheme.primaryColor,
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                Text(
                                  'عدد الليالي: ${b.nights}',
                                  style: GoogleFonts.cairo(fontSize: 14),
                                ),
                                Text(
                                  'تاريخ البدء: ${b.startDate.toLocal().toString().split(' ')[0]}',
                                  style: GoogleFonts.cairo(fontSize: 14),
                                ),
                                Row(
                                  children: [
                                    Text(
                                      'الحالة: ',
                                      style: GoogleFonts.cairo(fontSize: 14),
                                    ),
                                    Text(
                                      b.status,
                                      style: GoogleFonts.cairo(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: _statusColor(b.status),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            isThreeLine: true,
                            trailing: canCancel
                                ? IconButton(
                                    icon: const Icon(
                                      Icons.cancel,
                                      size: 26,
                                      color: Colors.redAccent,
                                    ),
                                    tooltip: 'إلغاء الحجز',
                                    onPressed: () => _cancelBooking(b.id),
                                  )
                                : const Icon(
                                    Icons.arrow_forward_ios_rounded,
                                    size: 22,
                                  ),
                            onTap: () {
                              Navigator.pushNamed(
                                context,
                                '/booking_details',
                                arguments: b,
                              );
                            },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTab(String label, int index) {
    final isSelected = selectedTab == index;
    return GestureDetector(
      onTap: () => setState(() => selectedTab = index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryColor.withAlpha((0.11 * 255).round())
              : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          label,
          style: GoogleFonts.cairo(
            fontWeight: FontWeight.w600,
            color: isSelected ? AppTheme.primaryColor : Colors.black54,
          ),
        ),
      ),
    );
  }
}
