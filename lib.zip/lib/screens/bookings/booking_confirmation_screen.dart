import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class BookingConfirmationScreen extends StatelessWidget {
  final String guestName;
  final String propertyName;
  final DateTime checkInDate;
  final DateTime checkOutDate;
  final String bookingCode;

  const BookingConfirmationScreen({
    super.key,
    required this.guestName,
    required this.propertyName,
    required this.checkInDate,
    required this.checkOutDate,
    required this.bookingCode,
  });

  String _formatDate(DateTime date) => '${date.day}/${date.month}/${date.year}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'تأكيد الحجز',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: AppTheme.primaryColor),
        elevation: 0,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'تم قبول الحجز من قبل:',
              style: GoogleFonts.cairo(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryColor,
              ),
            ),
            const SizedBox(height: 14),
            _infoText('الضيف: $guestName'),
            _infoText('العقار: $propertyName'),
            _infoText('تاريخ الوصول: ${_formatDate(checkInDate)}'),
            _infoText('تاريخ المغادرة: ${_formatDate(checkOutDate)}'),
            const SizedBox(height: 30),
            Text(
              'كود تأكيد الحجز:',
              style: GoogleFonts.cairo(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppTheme.accentColor,
              ),
            ),
            Center(
              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 20),
                padding: const EdgeInsets.symmetric(
                  horizontal: 36,
                  vertical: 20,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.accentColor.withAlpha(30),
                  border: Border.all(color: AppTheme.accentColor, width: 3),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  bookingCode,
                  style: GoogleFonts.cairo(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    color: AppTheme.accentColor,
                    letterSpacing: 3,
                  ),
                ),
              ),
            ),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryColor,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                      ),
                    ),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'تم تأكيد وصولك بنجاح ✅',
                            style: GoogleFonts.cairo(),
                          ),
                          backgroundColor: AppTheme.primaryColor,
                          behavior: SnackBarBehavior.floating,
                        ),
                      );
                    },
                    child: Text(
                      'تأكيد الوصول',
                      style: GoogleFonts.cairo(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 18),
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: AppTheme.primaryColor, width: 2),
                      foregroundColor: AppTheme.primaryColor,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                      ),
                    ),
                    onPressed: () {
                      showModalBottomSheet(
                        context: context,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.vertical(
                            top: Radius.circular(24),
                          ),
                        ),
                        builder: (context) => Padding(
                          padding: const EdgeInsets.symmetric(
                            vertical: 16,
                            horizontal: 24,
                          ),
                          child: Wrap(
                            children: [
                              ListTile(
                                leading: const Icon(
                                  Icons.edit,
                                  color: Colors.teal,
                                ),
                                title: Text(
                                  'تعديل الحجز',
                                  style: GoogleFonts.cairo(),
                                ),
                                onTap: () {
                                  Navigator.pop(context);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        'ميزة تعديل الحجز قيد التطوير',
                                        style: GoogleFonts.cairo(),
                                      ),
                                      backgroundColor: Colors.orange,
                                      behavior: SnackBarBehavior.floating,
                                    ),
                                  );
                                },
                              ),
                              ListTile(
                                leading: const Icon(
                                  Icons.cancel,
                                  color: Colors.redAccent,
                                ),
                                title: Text(
                                  'إلغاء الحجز',
                                  style: GoogleFonts.cairo(
                                    color: Colors.redAccent,
                                  ),
                                ),
                                onTap: () {
                                  Navigator.pop(context);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        'تم إلغاء الحجز',
                                        style: GoogleFonts.cairo(),
                                      ),
                                      backgroundColor: Colors.redAccent,
                                      behavior: SnackBarBehavior.floating,
                                    ),
                                  );
                                },
                              ),
                              ListTile(
                                leading: const Icon(Icons.close),
                                title: Text(
                                  'إغلاق',
                                  style: GoogleFonts.cairo(),
                                ),
                                onTap: () => Navigator.pop(context),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                    child: Text(
                      'تعديل أو رفض',
                      style: GoogleFonts.cairo(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.primaryColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoText(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Text(
      text,
      style: GoogleFonts.cairo(fontSize: 16, color: Colors.black87),
    ),
  );
}
