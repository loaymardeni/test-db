import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';

import '../../theme/app_theme.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  int _selectedTab = 0;

  final List<Map<String, String>> _favoriteProperties = [
    {
      'title': 'شقة راقية في دمشق',
      'subtitle': 'دمشق - أبو رمانة',
      'imageUrl': 'https://via.placeholder.com/200',
    },
    {
      'title': 'منزل ريفي في حلب',
      'subtitle': 'حلب - دير حافر',
      'imageUrl': 'https://via.placeholder.com/200',
    },
  ];

  final List<Map<String, String>> _recentlyViewed = [
    {
      'title': 'شقة في وسط المدينة',
      'subtitle': 'دمشق - المزة',
      'imageUrl': 'https://via.placeholder.com/200',
    },
    {
      'title': 'غرفة للإيجار في الحجر الأسود',
      'subtitle': 'دمشق - الحجر الأسود',
      'imageUrl': 'https://via.placeholder.com/200',
    },
  ];

  void _removeFavorite(int index) {
    setState(() {
      _favoriteProperties.removeAt(index);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تمت إزالة من المفضلة', style: GoogleFonts.cairo()),
        backgroundColor: Colors.redAccent,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final items = _selectedTab == 0 ? _favoriteProperties : _recentlyViewed;
    final isFavTab = _selectedTab == 0;

    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: Text(
          'المفضلة',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(color: AppTheme.primaryColor),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildTab('المفضلة', 0),
                  const SizedBox(width: 16),
                  _buildTab('شوهد مؤخراً', 1),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: items.isEmpty
                  ? Center(
                      child: Text(
                        isFavTab
                            ? 'لا يوجد عناصر مفضّلة'
                            : 'لم تشاهد أي عناصر بعد',
                        style: GoogleFonts.cairo(fontSize: 16),
                      ),
                    )
                  : GridView.builder(
                      padding: const EdgeInsets.all(16),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 16,
                            crossAxisSpacing: 16,
                            childAspectRatio: 0.75,
                          ),
                      itemCount: items.length,
                      itemBuilder: (context, i) {
                        final item = items[i];
                        return Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 6,
                                offset: Offset(0, 3),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ClipRRect(
                                borderRadius: const BorderRadius.vertical(
                                  top: Radius.circular(16),
                                ),
                                child: Image.network(
                                  item['imageUrl']!,
                                  height: 120,
                                  width: double.infinity,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  item['title']!,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.cairo(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                ),
                                child: Text(
                                  item['subtitle']!,
                                  style: GoogleFonts.cairo(
                                    fontSize: 13,
                                    color: AppTheme.greyColor,
                                  ),
                                ),
                              ),
                              const Spacer(),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 6,
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    if (isFavTab)
                                      GestureDetector(
                                        onTap: () => _removeFavorite(i),
                                        child: const Icon(
                                          Icons.favorite,
                                          color: Colors.red,
                                        ),
                                      )
                                    else
                                      const SizedBox(width: 24),
                                    TextButton(
                                      onPressed: () {
                                        context.push(
                                          '/property_details',
                                          extra: {
                                            'title': item['title'],
                                            'subtitle': item['subtitle'],
                                            'imageUrl': item['imageUrl'],
                                          },
                                        );
                                      },
                                      child: Text(
                                        'تفاصيل',
                                        style: GoogleFonts.cairo(
                                          color: AppTheme.primaryColor,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTab(String label, int idx) {
    final active = _selectedTab == idx;
    return GestureDetector(
      onTap: () => setState(() => _selectedTab = idx),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: active
              ? AppTheme.primaryColor.withAlpha((0.1 * 255).round())
              : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          label,
          style: GoogleFonts.cairo(
            fontWeight: active ? FontWeight.bold : FontWeight.w500,
            color: active ? AppTheme.primaryColor : Colors.black54,
          ),
        ),
      ),
    );
  }
}
