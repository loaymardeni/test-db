import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SplashScreen extends StatefulWidget {
  final bool seenOnboarding;

  const SplashScreen({super.key, required this.seenOnboarding});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _textController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();

    _textController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _fadeAnimation = CurvedAnimation(
      parent: _textController,
      curve: Curves.easeIn,
    );

    _textController.forward();

    Timer(const Duration(seconds: 3), () {
      if (widget.seenOnboarding) {
        context.go('/main');
      } else {
        context.go('/onboarding');
      }
    });
  }

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment(-0.4, -0.9),
            end: Alignment(0.4, 0.9),
            colors: [Color(0xFFF5FEFF), Color(0xFFE6F4F4), Color(0xFF2D6FFF)],
            stops: [0.0, 0.5, 1.0],
          ),
        ),
        child: Stack(
          children: [
            // الشعار
            Positioned(
              top: size.height * 0.33,
              left: size.width * 0.5 - 77,
              child: Image.asset(
                'assets/images/logo.png', // تأكد أنو موجود فعلاً
                width: 154,
                height: 215,
                fit: BoxFit.contain,
              ),
            ),

            // الظل تحت الشعار
            Positioned(
              top: size.height * 0.60,
              left: size.width * 0.5 - 69,
              child: Container(
                width: 139,
                height: 20,
                decoration: BoxDecoration(
                  color: Color(0xFFD9D9D9),
                  borderRadius: BorderRadius.circular(69),
                ),
              ),
            ),

            // اسم التطبيق
            Positioned(
              top: size.height * 0.65,
              left: size.width * 0.5 - 60,
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: const Text(
                  'immo sy',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
            ),

            // الشعار النصي
            Positioned(
              top: size.height * 0.73,
              left: size.width * 0.5 - 117,
              child: SizedBox(
                width: 234,
                child: const Text(
                  'find your next rent. anywhere. anytime.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.black54,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
