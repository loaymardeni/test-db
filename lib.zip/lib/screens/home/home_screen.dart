import 'package:flutter/material.dart';

import '../../widgets/category_bar.dart';
import '../../widgets/horizontal_list_section.dart';

class HomeScreen extends StatefulWidget {
  final void Function(bool)? onThemeChanged;
  final bool isDarkMode;

  const HomeScreen({super.key, this.onThemeChanged, this.isDarkMode = false});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedCategory = 0;

  final List<Map<String, String>> categories = [
    {'title': 'عقارات (بيع)', 'icon': 'assets/animations/real_estate.json'},
    {'title': 'تأجير', 'icon': 'assets/animations/rooms.json'},
    {'title': 'سيارات', 'icon': 'assets/animations/car.json'},
    {'title': 'خدمات', 'icon': 'assets/animations/service.json'},
  ];

  final List<List<Map<String, dynamic>>> allSections = [
    [
      {
        'image': 'assets/images/house1.jpg',
        'title': 'منزل للبيع في دمشق',
        'subtitle': '4 غرف • المزة',
        'isFavorite': false,
      },
    ],
    [
      {
        'image': 'assets/images/room1.jpg',
        'title': 'غرفة للإيجار في حلب',
        'subtitle': 'سرير مفرد • الجميلية',
        'isFavorite': false,
      },
    ],
    [
      {
        'image': 'assets/images/car1.jpg',
        'title': 'سيارة للإيجار',
        'subtitle': 'موديل 2022 • أوتوماتيك',
        'isFavorite': false,
      },
    ],
    [
      {
        'image': 'assets/images/service1.jpg',
        'title': 'خدمة تنظيف منازل',
        'subtitle': 'متوفرة في دمشق • أسعار منافسة',
        'isFavorite': false,
      },
    ],
  ];

  void onCategorySelected(int i) {
    setState(() => selectedCategory = i);
  }

  void onFavorite(int idx) {
    setState(() {
      final curr = allSections[selectedCategory][idx];
      curr['isFavorite'] = !(curr['isFavorite'] as bool);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7FA),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        toolbarHeight: 72,
        title: TextField(
          decoration: InputDecoration(
            hintText: 'بدء البحث',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(vertical: 0),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(28),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ),
      body: ListView(
        children: [
          CategoryBar(
            selected: selectedCategory,
            onSelect: onCategorySelected,
            categories: categories,
          ),
          const SizedBox(height: 10),
          HorizontalListSection(
            title: categories[selectedCategory]['title']!,
            items: allSections[selectedCategory],
            onFavorite: onFavorite,
          ),
        ],
      ),
    );
  }
}
