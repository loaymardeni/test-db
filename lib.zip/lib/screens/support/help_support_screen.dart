import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../theme/app_theme.dart';

class HelpSupportScreen extends StatelessWidget {
  const HelpSupportScreen({super.key});

  void launchWhatsApp() async {
    const phone = '+963900000000';
    const message = 'مرحبًا، أحتاج مساعدة في تطبيق حربوق';
    final url = 'https://wa.me/$phone?text=${Uri.encodeComponent(message)}';
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      debugPrint('تعذر فتح واتساب');
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> faq = [
      {
        'q': 'كيف يمكنني إضافة عقار للإيجار؟',
        'a': 'من خلال شاشة "إدارة الإعلانات" ثم الضغط على "إضافة إعلان".',
      },
      {
        'q': 'هل يمكنني تعديل بيانات الحجز؟',
        'a': 'نعم، تواصل مع المضيف من خلال صفحة المحادثة.',
      },
      {
        'q': 'كيف أتواصل مع الدعم الفني؟',
        'a': 'من خلال واتساب أو إرسال شكوى من نفس هذه الشاشة.',
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'الدعم والمساعدة',
          style: GoogleFonts.cairo(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 21,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: AppTheme.primaryColor),
        elevation: 0.5,
        centerTitle: true,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            'الأسئلة الشائعة',
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.bold,
              fontSize: 20,
              color: AppTheme.primaryColor,
            ),
          ),
          const SizedBox(height: 12),
          ...faq.map(
            (item) => Card(
              margin: const EdgeInsets.symmetric(vertical: 5),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              elevation: 2,
              color: Colors.white,
              child: ExpansionTile(
                tilePadding: const EdgeInsets.symmetric(horizontal: 13),
                title: Text(
                  item['q']!,
                  style: GoogleFonts.cairo(
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                    color: AppTheme.primaryColor,
                  ),
                ),
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 15,
                      vertical: 6,
                    ),
                    child: Text(
                      item['a']!,
                      style: GoogleFonts.cairo(fontSize: 15),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Divider(height: 32),

          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => context.push('/support/ai'),
              icon: const Icon(Icons.smart_toy_outlined),
              label: Text(
                'استخدم المساعد الذكي',
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.primaryColor,
                side: BorderSide(color: AppTheme.primaryColor),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(13),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => launchWhatsApp(),
              icon: const Icon(Icons.chat),
              label: Text(
                'تواصل عبر واتساب',
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(13),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),

          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => context.push('/support/report'),
              icon: const Icon(Icons.report_problem),
              label: Text(
                'إرسال شكوى أو استفسار',
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: AppTheme.primaryColor,
                ),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.primaryColor,
                side: BorderSide(color: AppTheme.primaryColor),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(13),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
