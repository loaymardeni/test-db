import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';

import '../../theme/app_theme.dart';

class FaqCenterScreen extends StatelessWidget {
  const FaqCenterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final String category =
        GoRouterState.of(context).uri.queryParameters['id'] ?? 'الأسئلة العامة';

    final Map<String, List<Map<String, String>>> faqData = {
      'الحساب': [
        {'q': 'كيف أغير كلمة المرور؟', 'id': 'q1'},
        {'q': 'كيف أحذف حسابي؟', 'id': 'q2'},
      ],
      'الحجوزات': [
        {'q': 'كيف أعدل أو ألغي الحجز؟', 'id': 'q3'},
        {'q': 'ما شروط استرجاع المبلغ؟', 'id': 'q4'},
      ],
      'المدفوعات': [
        {'q': 'ما طرق الدفع المتاحة؟', 'id': 'q5'},
        {'q': 'واجهت مشكلة بالدفع، ماذا أفعل؟', 'id': 'q6'},
      ],
      'الأمان والاحتيال': [
        {'q': 'كيف أبلّغ عن مضيف مشبوه؟', 'id': 'q7'},
        {'q': 'كيف أحمي حسابي؟', 'id': 'q8'},
      ],
      'خدمات إضافية': [
        {'q': 'هل يوجد تأمين على العقارات؟', 'id': 'q9'},
        {'q': 'كيف أطلب خدمة تنظيف؟', 'id': 'q10'},
      ],
    };

    final questions = faqData[category] ?? [];

    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: Text(
          'أسئلة عن "$category"',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: questions.length,
        separatorBuilder: (context, index) => const Divider(),
        itemBuilder: (context, index) {
          final item = questions[index];
          return ListTile(
            leading: const Icon(Icons.help_outline),
            title: Text(
              item['q']!,
              style: GoogleFonts.cairo(fontWeight: FontWeight.w600),
            ),
            trailing: const Icon(Icons.chevron_left),
            onTap: () {
              context.push('/support/faq/${item['id']}');
            },
          );
        },
      ),
    );
  }
}
