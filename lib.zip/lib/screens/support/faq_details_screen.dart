import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../theme/app_theme.dart';

class FaqDetailsScreen extends StatelessWidget {
  final String faqId;

  const FaqDetailsScreen({super.key, required this.faqId});

  @override
  Widget build(BuildContext context) {
    // قاعدة بيانات بسيطة مؤقتة للأسئلة مع الإجابات
    final Map<String, Map<String, String>> faqAnswers = {
      'q1': {
        'question': 'كيف أغير كلمة المرور؟',
        'answer':
            'يمكنك تغيير كلمة المرور من خلال:\n1. الذهاب إلى إعدادات الحساب.\n2. اختيار "تسجيل الدخول والأمان".\n3. النقر على "تغيير كلمة المرور".\n\nثم إدخال كلمة المرور الحالية والجديدة وحفظ التغييرات.',
      },
      'q2': {
        'question': 'كيف أحذف حسابي؟',
        'answer':
            'نأسف لرغبتك في المغادرة!\nلحذف الحساب:\n1. توجه إلى "الخصوصية".\n2. مرر لأسفل وانقر على "حذف الحساب نهائيًا".\n\nسيُطلب منك تأكيد القرار.',
      },
      'q3': {
        'question': 'كيف أعدل أو ألغي الحجز؟',
        'answer':
            'لإجراء تعديل أو إلغاء:\n1. انتقل إلى صفحة "حجوزاتي".\n2. اختر الحجز المطلوب.\n3. انقر على "تعديل" أو "إلغاء".\n\nملاحظة: بعض الحجوزات غير قابلة للإلغاء بحسب سياسة المضيف.',
      },
      // أضف المزيد هنا حسب الحاجة
    };

    final data = faqAnswers[faqId];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'تفاصيل السؤال',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
      ),
      backgroundColor: AppTheme.backgroundColor,
      body: data == null
          ? Center(
              child: Text(
                'لم يتم العثور على هذا السؤال.',
                style: GoogleFonts.cairo(fontSize: 16),
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data['question']!,
                    style: GoogleFonts.cairo(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    data['answer']!,
                    style: GoogleFonts.cairo(fontSize: 16, height: 1.7),
                  ),
                  const Spacer(),
                  Center(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.arrow_back),
                      label: Text(
                        'الرجوع',
                        style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
                      ),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppTheme.primaryColor,
                        side: BorderSide(color: AppTheme.primaryColor),
                        padding: const EdgeInsets.symmetric(
                          vertical: 12,
                          horizontal: 24,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
