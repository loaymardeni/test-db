import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';

class SmartSupportScreen extends StatefulWidget {
  const SmartSupportScreen({super.key});

  @override
  State<SmartSupportScreen> createState() => _SmartSupportScreenState();
}

class _SmartSupportScreenState extends State<SmartSupportScreen> {
  int currentStep = 0;
  String? problemType;
  String? urgency;

  final List<String> types = [
    'مشكلة في الحجز',
    'مشكلة في الدفع',
    'مشكلة في الحساب',
    'اقتراح أو ملاحظة',
    'بلاغ أو احتيال',
  ];

  final List<String> urgencies = ['عادي', 'مستعجل', 'طارئ'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'مساعد الذكاء',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
      ),
      body: Stepper(
        type: StepperType.vertical,
        currentStep: currentStep,
        onStepContinue: () {
          if (currentStep < 2) {
            setState(() => currentStep++);
          } else {
            context.push('/support');
          }
        },
        onStepCancel: () {
          if (currentStep > 0) {
            setState(() => currentStep--);
          }
        },
        steps: [
          Step(
            title: const Text('ما نوع المشكلة؟'),
            content: DropdownButtonFormField<String>(
              decoration: const InputDecoration(border: OutlineInputBorder()),
              value: problemType,
              items: types
                  .map(
                    (type) => DropdownMenuItem(value: type, child: Text(type)),
                  )
                  .toList(),
              onChanged: (val) => setState(() => problemType = val),
            ),
            isActive: currentStep >= 0,
          ),
          Step(
            title: const Text('مدى الأهمية؟'),
            content: DropdownButtonFormField<String>(
              decoration: const InputDecoration(border: OutlineInputBorder()),
              value: urgency,
              items: urgencies
                  .map((u) => DropdownMenuItem(value: u, child: Text(u)))
                  .toList(),
              onChanged: (val) => setState(() => urgency = val),
            ),
            isActive: currentStep >= 1,
          ),
          Step(
            title: const Text('جاهز للتواصل مع الدعم؟'),
            content: const Text(
              'اضغط "التالي" للانتقال إلى صفحة الدعم والمساعدة',
            ),
            isActive: currentStep >= 2,
          ),
        ],
      ),
    );
  }
}
