import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:harbooq/theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  final bool isDarkMode;
  final ValueChanged<bool> onThemeChanged;

  const SettingsScreen({
    super.key,
    required this.isDarkMode,
    required this.onThemeChanged,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late bool _notificationsEnabled;
  late bool _darkModeEnabled;

  @override
  void initState() {
    super.initState();
    _notificationsEnabled = true;
    _darkModeEnabled = widget.isDarkMode;
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = AppTheme.primaryColor;
    final textColor = _darkModeEnabled ? Colors.white : Colors.black87;
    final backgroundColor = _darkModeEnabled
        ? Colors.black
        : AppTheme.backgroundColor;
    final appBarColor = _darkModeEnabled ? Colors.black87 : Colors.white;
    final iconColor = _darkModeEnabled ? Colors.white : primaryColor;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'الإعدادات',
          style: GoogleFonts.cairo(
            fontWeight: FontWeight.bold,
            color: textColor,
          ),
        ),
        backgroundColor: appBarColor,
        iconTheme: IconThemeData(color: iconColor),
        elevation: 0,
      ),
      backgroundColor: backgroundColor,
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            title: Text(
              'تمكين الإشعارات',
              style: GoogleFonts.cairo(fontSize: 16, color: textColor),
            ),
            value: _notificationsEnabled,
            onChanged: (bool value) {
              setState(() {
                _notificationsEnabled = value;
              });
            },
            activeColor: primaryColor,
            contentPadding: const EdgeInsets.symmetric(horizontal: 0),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            title: Text(
              'الوضع الداكن',
              style: GoogleFonts.cairo(fontSize: 16, color: textColor),
            ),
            value: _darkModeEnabled,
            onChanged: (bool value) {
              setState(() {
                _darkModeEnabled = value;
              });
              widget.onThemeChanged(value);
            },
            activeColor: primaryColor,
            contentPadding: const EdgeInsets.symmetric(horizontal: 0),
          ),
          const SizedBox(height: 20),
          Divider(color: Colors.grey.shade400, thickness: 1, height: 32),
          ListTile(
            title: Text(
              'تغيير كلمة المرور',
              style: GoogleFonts.cairo(fontSize: 16, color: textColor),
            ),
            trailing: Icon(Icons.arrow_forward_ios, color: iconColor, size: 20),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'هذه الميزة قيد التطوير حاليًا',
                    style: GoogleFonts.cairo(),
                  ),
                  backgroundColor: _darkModeEnabled
                      ? Colors.grey[800]!
                      : primaryColor.withAlpha((0.9 * 255).round()),
                ),
              );
            },
          ),
          const SizedBox(height: 6),
          ListTile(
            title: Text(
              'تسجيل الخروج',
              style: GoogleFonts.cairo(fontSize: 16, color: textColor),
            ),
            trailing: Icon(
              Icons.logout,
              color: _darkModeEnabled ? Colors.red[300] : Colors.redAccent,
            ),
            onTap: () {
              Navigator.pushNamedAndRemoveUntil(
                context,
                '/login',
                (route) => false,
              );
            },
          ),
        ],
      ),
    );
  }
}
